const Sequelize = require("sequelize");
const dbConfig = require("./config");

const connection = new Sequelize({
    ...dbConfig,
    dialect: 'mysql'
});

const Usuario = require("../src/models/Usuario");
const Atletica = require("../src/models/Atletica");
const Curso = require("../src/models/Curso");
const AtleticaCurso = require("../src/models/AtleticaCurso");
const MembroAtletica = require("../src/models/MembroAtletica");
const PlanoAssinatura = require("../src/models/PlanoAssinatura");
const Assinatura = require("../src/models/Assinatura");
const Pagamento = require("../src/models/Pagamento");
const PagamentoAssinatura = require("../src/models/PagamentoAssinatura");
const Produto = require("../src/models/Produto");
const CarrinhoCompra = require("../src/models/CarrinhoCompra");
const ProdutoCarrinhoCompra = require("../src/models/ProdutoCarrinhoCompra");
const Pedido = require("../src/models/Pedido");
const Evento = require("../src/models/Evento");
const UsuarioEvento = require("../src/models/UsuarioEvento");
const PagamentoPedido = require("../src/models/PagamentoPedido");

Usuario.init(connection);
Atletica.init(connection);
Curso.init(connection);
AtleticaCurso.init(connection);
MembroAtletica.init(connection);
PlanoAssinatura.init(connection);
Assinatura.init(connection);
Pagamento.init(connection);
PagamentoAssinatura.init(connection);
Produto.init(connection);
CarrinhoCompra.init(connection);
ProdutoCarrinhoCompra.init(connection);
Pedido.init(connection);
Evento.init(connection);
UsuarioEvento.init(connection);
PagamentoPedido.init(connection);

Usuario.associate(connection.models);
Atletica.associate(connection.models);
Curso.associate(connection.models);
MembroAtletica.associate(connection.models);
PlanoAssinatura.associate(connection.models);
Assinatura.associate(connection.models);
Pagamento.associate(connection.models);
PagamentoAssinatura.associate(connection.models);
Produto.associate(connection.models);
CarrinhoCompra.associate(connection.models);
ProdutoCarrinhoCompra.associate(connection.models);
Pedido.associate(connection.models);
Evento.associate(connection.models);
UsuarioEvento.associate(connection.models);
PagamentoPedido.associate(connection.models);

module.exports = connection;