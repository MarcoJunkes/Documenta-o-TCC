'use strict';

/** @type {import('sequelize-cli').Migration} */
module.exports = {
  async up (queryInterface, Sequelize) {
    await queryInterface.createTable('Evento', {
      id: {
        allowNull: false,
        autoIncrement: true,
        primaryKey: true,
        type: Sequelize.INTEGER
      },
      data: {
        type: Sequelize.STRING,
        allowNull: false
      },
      hora: {
        type: Sequelize.STRING,
        allowNull: false
      },
      endereco: {
        type: Sequelize.STRING,
        allowNull: false
      },
      titulo: {
        type: Sequelize.STRING,
        allowNull: false
      },
      descricao: {
        type: Sequelize.STRING,
        allowNull: false
      },
      linkPlataformaIngressos: {
        type: Sequelize.STRING,
        allowNull: true
      },
      qtdeVagas: {
        type: Sequelize.INTEGER,
        allowNull: true
      },
      ingresso: {
        type: Sequelize.INTEGER,
        allowNull: true
      },
      statusEvento: {
        type: Sequelize.ENUM('CONCLUIDO', 'CANCELADO', 'EM_ANDAMENTO'),
        allowNull: false
      },
      modalidade: {
        type: Sequelize.ENUM('FESTA', 'JOGO'),
        allowNull: false
      },
      atleticaId: {
        type: Sequelize.INTEGER,
				allowNull: true,
        references: {
          model: "Atletica", key: "id"
        },
        onUpdate: "CASCADE",
        onDelete: "SET NULL",
      },
      atleticaName: {
        type: Sequelize.STRING,
        allowNull: false
      },
      createdAt: {
        allowNull: false,
        type: Sequelize.DATE,
        defaultValue: Sequelize.literal("CURRENT_TIMESTAMP"),
      },
      updatedAt: {
        allowNull: false,
        type: Sequelize.DATE,
        defaultValue: Sequelize.literal("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP"),
      }
    });
  },

  async down (queryInterface, Sequelize) {
    await queryInterface.dropTable('Evento');
  }
};