'use strict';

/** @type {import('sequelize-cli').Migration} */
module.exports = {
  async up (queryInterface, Sequelize) {
    await queryInterface.createTable("ProdutoCarrinhoCompra", {
      id: {
        type: Sequelize.INTEGER,
        primaryKey: true,
        autoIncrement: true,
        allowNull: false
      },
      produtoId: {
        type: Sequelize.INTEGER,
        allowNull: false,
        references: {model: "Produto", key: "id"},
        onUpdate: "RESTRICT",
        onDelete: "RESTRICT"
      },
      carrinhoCompraId: {
        type: Sequelize.INTEGER,
        allowNull: false,
        references: {model: "CarrinhoCompra", key: "id"},
        onUpdate: "RESTRICT",
        onDelete: "RESTRICT"
      },
      quantidade: {
        type: Sequelize.INTEGER,
        allowNull: false
      },
      createdAt: {
        type: Sequelize.DATE,
        allowNull: false,
        defaultValue: Sequelize.literal("CURRENT_TIMESTAMP"),
      },
      updatedAt: {
        type: Sequelize.DATE,
        allowNull: false,
        defaultValue: Sequelize.literal("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP"),
      },
    })
  },

  async down (queryInterface, Sequelize) {
    await queryInterface.dropTable("ProdutoCarrinhoCompra");
  }
};
