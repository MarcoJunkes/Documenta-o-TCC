'use strict';

/** @type {import('sequelize-cli').Migration} */
module.exports = {
  async up (queryInterface, Sequelize) {
    await queryInterface.createTable("MembroAtletica", {
      id: {
        type: Sequelize.INTEGER,
        primaryKey: true,
        autoIncrement: true,
        allowNull: false,
      },

      administrador: {
        type: Sequelize.BOOLEAN,
        defaultValue: false,
        allowNull: false,
      },

      //relação com a tabela Usuario
      usuarioId: {
        type: Sequelize.INTEGER,
        allowNull: false,
        references: {
          model: "Usuario", key: "id"
        },
        onUpdate: "CASCADE",
        //quando a chave primária for atualizada, a chave estrangeira também vai ser
        onDelete: "SET NULL",
        //quando o registro ref for excluído, a chave estrangeira é definida null
        allowNull: true,
        //adicionado pois deu erro, agora quando um campo em usuarios for deletado, aqui exibe null também
      },

      atleticaId: {
        type: Sequelize.INTEGER,
        references: {
          model: "Atletica", key: "id"
        },

        onUpdate: "CASCADE",
        onDelete: "SET NULL",
        allowNull: true,
      },

      createdAt: {
        type: Sequelize.DATE,
        allowNull: false,
        defaultValue: Sequelize.literal("CURRENT_TIMESTAMP"),
      },

      updatedAt: {
        type: Sequelize.DATE,
        allowNull: false,
        defaultValue: Sequelize.literal("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP"),
      },

    });
  },

  async down (queryInterface, Sequelize) {
    await queryInterface.dropTable("MembroAtletica");
  }
};
