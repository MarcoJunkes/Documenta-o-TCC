const express = require("express");
const cors = require("cors");
const bodyParser = require("body-parser");
const router = require("./routes/router");
const swaggerUi = require('swagger-ui-express');
const swaggerDocument = require('../swagger.json');
const path = require("path"); 
require("../config/index");
const webhookRouter = require("./routes/webhookRouter");

const app = express();

app.use(cors());

app.use(
    bodyParser.json({
        verify: function(req, res, buf) {
            req.rawBody = buf;
        }
    })
);

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));
app.use('/api', webhookRouter);

app.use("/uploads", express.static(path.resolve(__dirname, "uploads")));

app.use(router);

app.use('/api-docs', swaggerUi.serve, swaggerUi.setup(swaggerDocument));

app.listen(process.env.SYSTEM_PORT, () => {
    console.log("Servidor executando na porta: ", process.env.SYSTEM_PORT);
});

module.exports = app;
