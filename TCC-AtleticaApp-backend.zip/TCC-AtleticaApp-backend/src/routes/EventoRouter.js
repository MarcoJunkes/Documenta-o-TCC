const express = require("express");
const EventoRouter = express.Router();
const EventoController = require("../controllers/EventoController");
const auth = require("../middlewares/auth");

EventoRouter.post("/criarEvento", auth, EventoController.criarEvento);
EventoRouter.delete("/excluirEvento/:id", auth, EventoController.excluirEvento);
EventoRouter.get("/listarEvento", auth, EventoController.listarEvento);
EventoRouter.get("/selecionarEvento/:id", auth, EventoController.selecionarEvento);
EventoRouter.post("/participarEvento/:id", auth, EventoController.participarEvento);
EventoRouter.delete("/cancelarParticipacao/:id", auth, EventoController.cancelarParticipacao);
EventoRouter.get("/meusEventos", auth, EventoController.meusEventos);
EventoRouter.get("/listarInscritos/:id", auth, EventoController.listarInscritos);

module.exports = EventoRouter;