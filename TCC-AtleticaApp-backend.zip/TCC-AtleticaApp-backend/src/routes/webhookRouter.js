const express = require("express");
const webhookController = require("../controllers/webhookController");
const bodyParser = require("body-parser");

const webhookRouter = express.Router();

webhookRouter.post(
  '/webhook',
  bodyParser.raw({ type: 'application/json' }),
  webhookController.handleWebhook
);

module.exports = webhookRouter;
