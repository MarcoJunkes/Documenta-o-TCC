const express = require("express");
const planoAssinaturaController = require("../controllers/PlanoAssinaturaController");
const planoAssinaturaRouter = express.Router();
const auth = require("../middlewares/auth");

planoAssinaturaRouter.post("/cadastrarPlano", auth, planoAssinaturaController.addPlano);
planoAssinaturaRouter.get("/listarPlanos", auth, planoAssinaturaController.exibirPlanos);
planoAssinaturaRouter.get("/selecionarPlano/:id", auth, planoAssinaturaController.selecionarPlanos);
planoAssinaturaRouter.put("/editarPlano/:id", auth, planoAssinaturaController.editarPlano);
planoAssinaturaRouter.delete("/removerPlano/:id", auth, planoAssinaturaController.removerPlano);
planoAssinaturaRouter.get("/visualizarAssinantes/:id", auth, planoAssinaturaController.visualizarAssinantes);
planoAssinaturaRouter.get("/buscarPorAtletica/:id", auth, planoAssinaturaController.buscarPorAtletica);

module.exports = planoAssinaturaRouter;