const express = require("express");
const produtoController = require("../controllers/ProdutoController");
const produtoRouter = express.Router();
const upload = require("../multer/multerConfig");
const auth = require("../middlewares/auth");

produtoRouter.get("/listarProdutos", auth, produtoController.listarProdutos);
produtoRouter.get("/listarProdutosPorAtletica/:id", auth, produtoController.listarProdutosPorAtletica);
produtoRouter.post("/addProduto", auth, upload.single('imagem'), produtoController.addProduto);
produtoRouter.put("/editarProduto/:id", auth, upload.single('imagem'), produtoController.editarProduto);
produtoRouter.delete("/deletarProduto/:id", auth, produtoController.deletarProduto);

module.exports = produtoRouter;
