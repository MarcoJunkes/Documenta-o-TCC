const express = require("express");
const cursoRouter = express.Router();
const cursoController = require("../controllers/CursoController");

cursoRouter.get("/retornarCursos", cursoController.retornarCursos);

module.exports = cursoRouter;