const express = require("express");
const membroAtleticaRouter = express.Router();
const MembroAtleticaController = require("../controllers/MembroAtleticaController");
const auth = require("../middlewares/auth");

membroAtleticaRouter.get("/listarMembros/atletica/:atleticaId", auth, MembroAtleticaController.listarMembros);
membroAtleticaRouter.put("/editarMembro/:email", auth, MembroAtleticaController.editarMembro);
membroAtleticaRouter.post("/adicionarMembro", auth, MembroAtleticaController.adicionarMembro);
membroAtleticaRouter.delete("/removerMembro/:email", auth, MembroAtleticaController.removerMembro);

module.exports = membroAtleticaRouter;