const express = require("express");
const pedidoController = require("../controllers/PedidoController");
const pedidoRouter = express.Router();
const auth = require("../middlewares/auth");

pedidoRouter.post("/criarPedido", auth, pedidoController.criarPedido);
pedidoRouter.get("/listarPedido", auth, pedidoController.listarPedidos);
pedidoRouter.put("/cancelarPedido/:pedidoId", auth, pedidoController.cancelarPedido);
pedidoRouter.get("/selecionarPedido/:pedidoId", auth, pedidoController.selecionarPedido);

module.exports = pedidoRouter;