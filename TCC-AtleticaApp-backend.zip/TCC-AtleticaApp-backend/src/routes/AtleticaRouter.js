const express = require("express");
const atleticaRouter = express.Router();
const atleticaController = require("../controllers/AtleticaController");
const upload = require("../multer/multerConfig");
const auth = require("../middlewares/auth");

atleticaRouter.post("/cadastrarAtletica", auth, upload.single('imagem') ,atleticaController.cadastrarAtletica);
atleticaRouter.get("/listarAtletica", auth, atleticaController.listarAtletica);
atleticaRouter.get("/selecionarAtletica/:id", auth, atleticaController.selecionarAtletica);
atleticaRouter.put("/editarAtletica/:id", auth, upload.single('imagem'), atleticaController.editarAtletica);
atleticaRouter.delete("/deletarAtletica/:id", auth, atleticaController.deletarAtletica);

module.exports = atleticaRouter;