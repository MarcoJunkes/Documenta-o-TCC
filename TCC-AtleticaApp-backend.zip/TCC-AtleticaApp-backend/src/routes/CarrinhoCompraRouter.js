const express = require("express");
const carrinhoRouter = express.Router();
const carrinhoController = require("../controllers/CarrinhoCompra");
const auth = require("../middlewares/auth");

carrinhoRouter.post("/inserirProduto/:id", auth, carrinhoController.addProduto);
carrinhoRouter.get("/listarProdutos", auth, carrinhoController.listarProdutos);
carrinhoRouter.delete("/removerProduto/:id", auth, carrinhoController.removerProduto);
carrinhoRouter.delete("/excluirCarrinho", auth, carrinhoController.excluirCarrinho);

module.exports = carrinhoRouter;