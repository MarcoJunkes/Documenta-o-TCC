const express = require("express");
const usuarioRouter = require("./UsuarioRouter");
const atleticaRouter = require("./AtleticaRouter");
const cursoRouter = require("./CursoRouter");
const membroAtleticaRouter = require("./MembroAtleticaRouter");
const planoAssinaturaRouter = require("./PlanoAssinaturaRouter");
const assinaturaRouter = require("./AssinaturaRouter");
const pagamentoRouter = require("./PagamentoRouter");
const webhookRouter = require("./webhookRouter");
const produtoRouter = require("./ProdutoRouter");
const carrinhoCompra = require("./CarrinhoCompraRouter");
const eventoRouter = require("./EventoRouter");
const pedidoRouter = require("./PedidoRouter");

const router = express.Router();

router.get("/", (req, res) => {
    res.send("Está funcionando");
});

router.use("/usuario", usuarioRouter);
router.use("/atletica", atleticaRouter);
router.use("/curso", cursoRouter);
router.use("/membroatletica", membroAtleticaRouter);
router.use("/planoassinatura", planoAssinaturaRouter);
router.use("/assinatura", assinaturaRouter);
router.use("/pagamento", pagamentoRouter);
router.use("/", webhookRouter);
router.use("/produto", produtoRouter);
router.use("/carrinhocompra", carrinhoCompra);
router.use("/evento", eventoRouter);
router.use("/pedido", pedidoRouter);

module.exports = router;