const express = require("express");
const usuarioRouter = express.Router();
const usuarioController = require("../controllers/UsuarioController");
const verifyJWT = require("../middlewares/auth");

usuarioRouter.post("/authentication", usuarioController.authentication);
usuarioRouter.post("/sendEmail", usuarioController.enviarCodigoVerificacao);
usuarioRouter.post("/validarToken", usuarioController.validarCodigo);
usuarioRouter.post("/cadastrarUsuario", verifyJWT, usuarioController.cadastrarUsuario);
usuarioRouter.post("/recuperarSenha", usuarioController.enviarCodigoVerificacao);
usuarioRouter.put("/novaSenha", usuarioController.novaSenha);

module.exports = usuarioRouter;