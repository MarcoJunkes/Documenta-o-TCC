const express = require("express");
const pagamentoController = require("../controllers/PagamentoController");
const pagamentoRouter = express.Router();
const auth = require("../middlewares/auth");

pagamentoRouter.post("/realizarPagamento/:id", auth, pagamentoController.realizarPagamento);
pagamentoRouter.post("/pagarPedido/:id", auth, pagamentoController.realizarPagamentoPedido);

module.exports = pagamentoRouter;