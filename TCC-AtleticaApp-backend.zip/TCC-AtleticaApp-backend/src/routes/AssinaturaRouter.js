const express = require("express");
const assinaturaController = require("../controllers/AssinaturaController");
const assinaturaRouter = express.Router();
const auth = require("../middlewares/auth");

assinaturaRouter.post("/realizarAssinatura/:id", auth, assinaturaController.realizarAssinatura);
assinaturaRouter.get("/visualizarAssinaturas", auth, assinaturaController.visualizarAssinaturas);
assinaturaRouter.get("/selecionarAssinatura/:id", auth, assinaturaController.selecionarAssinatura);
assinaturaRouter.put("/cancelarAssinatura/:id", auth, assinaturaController.cancelarAssinatura);

module.exports = assinaturaRouter;