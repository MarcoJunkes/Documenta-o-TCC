const AuthService = require("../services/authService");
const Atletica = require("../models/Atletica");
const AtleticaCurso = require("../models/AtleticaCurso");
const MembroAtletica = require("../models/MembroAtletica");
const Curso = require("../models/Curso");

const jwt = require("jsonwebtoken");
const Usuario = require("../models/Usuario");

module.exports = {
			async cadastrarAtletica(req, res) {
        const { nome, descricao, atividades, cursoIds } = req.body;
        const token = req.headers["x-access-token"];

			if (!nome || !descricao || !atividades || !cursoIds ) {
				return res.status(400).json({ msg: "Campos obrigatórios não preenchidos!" });
        }

        try {
            // Verifica se o usuário tem permissão de acesso
            await AuthService.verificaPermissao(token, ["master"]);

            const atleticasExistentes = await Atletica.findOne({ where: { nome } });
            if (atleticasExistentes) {
                return res.status(409).json({ msg: "Atlética já cadastrada!" });
            }
            
            const imagem = req.file ? req.file.path : null;

            const parsedAtividades = Array.isArray(atividades) ? atividades : JSON.parse(atividades);

            const atletica = await Atletica.create({
                nome,
                descricao,
                imagem,
                atividades: parsedAtividades,
								cursoIds
            });

            await atletica.setCursos(cursoIds);
            return res.status(201).json({ msg: "Atlética cadastrada com sucesso!", atletica });
        } catch (error) {
            console.error(error.message || error);
            return res.status(401).json({ msg: error.message });
        }
    },

    async listarAtletica(req, res) {
        try {
            const atleticas = await Atletica.findAll();
            const resultado = [];
    
            for (const atletica of atleticas) {
                const atleticaCursos = await AtleticaCurso.findAll({ where: { atleticaId: atletica.id } });
                
                const cursos = await Promise.all(atleticaCursos.map(async (atleticaCurso) => {
                    const curso = await Curso.findOne({ where: { id: atleticaCurso.cursoId } });
                    return curso ? curso : null;
                }));
    
                let parsedAtividades;
                try {
                    parsedAtividades = Array.isArray(atletica.atividades) ? atletica.atividades : JSON.parse(atletica.atividades);
                } catch (error) {
                    parsedAtividades = atletica.atividades;
                }

                resultado.push({
                    atletica: {
                        ...atletica.toJSON(),
                        atividades: parsedAtividades,
												cursos: cursos.filter(curso => curso !== null)
                    },
                });
            }
    
            return res.status(200).json(resultado);
        } catch (error) {
            console.error(error);
            return res.status(500).json({ msg: "Erro de servidor" });
        }
    },
    

    async selecionarAtletica(req, res) {
        const { id } = req.params;
        if (!id) return res.status(400).json({ msg: "Campo obrigatório não informado" });
    
        try {
            const atletica = await Atletica.findByPk(id);
            if (!atletica) return res.status(404).json({ msg: "Atlética não encontrada" });
    
            const atleticaCursos = await AtleticaCurso.findAll({ where: { atleticaId: atletica.id } });
            
            const cursos = await Promise.all(atleticaCursos.map(async (atleticaCurso) => {
                const curso = await Curso.findOne({ where: { id: atleticaCurso.cursoId } });
                return curso ? curso : null;
            }));

            let parsedAtividades;
            try {
                parsedAtividades = Array.isArray(atletica.atividades) ? atletica.atividades : JSON.parse(atletica.atividades);
            } catch (error) {
                parsedAtividades = atletica.atividades;
            }
    
            return res.status(200).json({
                atletica: {
                    ...atletica.toJSON(),
                    atividades: parsedAtividades,
										cursos: cursos.filter(curso => curso !== null)
                },
            });
        } catch (error) {
            console.error(error);
            return res.status(500).json({ msg: "Erro no servidor" });
        }
    },
    

		async editarAtletica(req, res) {
			const { id } = req.params;
			const { nome, descricao, atividades, cursoIds } = req.body;
			const token = req.headers["x-access-token"];
	
			if (!id) return res.status(400).json({ msg: "ID não fornecido" });
	
			try {
					const decoded = jwt.verify(token, process.env.JWT_SECRET);
					await AuthService.verificaPermissao(token, ["master", "ADMIN"]);
	
					const atletica = await Atletica.findByPk(id);
					if (!atletica) return res.status(404).json({ msg: "Atlética não encontrada" });
	
					const usuario = await Usuario.findOne({ where: { id: decoded.id } });
	
					const membroAtletica = await MembroAtletica.findOne({
							where: {
									atleticaId: atletica.id,
									usuarioId: decoded.id,
							},
					});
	
					if (usuario.tipo !== "master" && (usuario.tipo !== "ADMIN" || !membroAtletica)) {
							return res.status(401).json({ msg: "Usuário sem permissão de acesso!" });
					}

					const imagem = req.file ? req.file.path : atletica.imagem;
	
					const parsedAtividades = Array.isArray(atividades) ? atividades : JSON.parse(atividades);
	
					await atletica.update({
							nome,
							descricao,
							atividades: parsedAtividades,
							imagem,
							cursoIds
					});
	
					if (cursoIds) {
            await AtleticaCurso.destroy({ where: { atleticaId: id } });
            await AtleticaCurso.bulkCreate(cursoIds.map(cursoId => ({
                atleticaId: id,
                cursoId,
            })));
        }
	
				return res.status(200).json({ msg: "Atlética atualizaa com sucesso!", atletica });
			} catch (error) {
					console.error(error.message || error);
					return res.status(401).json({ msg: error.message });
			}
	},

    async deletarAtletica(req, res) {
        const { id } = req.params;
        const token = req.headers["x-access-token"];

        if (!id) return res.status(400).json({ msg: "Id não fornecido" });

        try {
            await AuthService.verificaPermissao(token, ["master"]);

            const atleticaExistente = await Atletica.findByPk(id);
            if (!atleticaExistente) return res.status(404).json({ msg: "Atlética inexistente" });

            await MembroAtletica.destroy({where: { atleticaId: id }});
            await AtleticaCurso.destroy({ where: { atleticaId: id } });
            await atleticaExistente.destroy();

            return res.status(200).json({ msg: "Atlética deletada com sucesso" });
        } catch (error) {
            console.error(error.message || error);
            return res.status(401).json({ msg: error.message });
        }
    }
};
