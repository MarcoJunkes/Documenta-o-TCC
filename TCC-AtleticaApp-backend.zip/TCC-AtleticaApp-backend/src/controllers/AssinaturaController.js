const Assinatura = require("../models/Assinatura");
const PlanoAssinatura = require("../models/PlanoAssinatura");
const Atletica = require("../models/Atletica");
const jwt = require("jsonwebtoken");

const verificarExpiracaoAssinatura = async (assinatura) => {
    const dataAtual = new Date(new Date().toLocaleString("en-US", { timeZone: "America/Sao_Paulo" }));
    const dataFim = new Date(new Date(assinatura.dataFim).toLocaleString("en-US", { timeZone: "America/Sao_Paulo" }));

    if (dataFim < dataAtual) {
        await assinatura.update({
            statusAssinatura: "CANCELADA"
        });
        await assinatura.save();
    }
};

module.exports = {
    async realizarAssinatura(req, res) {
        const { id } = req.params;
        const token = req.headers["x-access-token"];
    
        if (!id) return res.status(400).json({ msg: "Plano não fornecido!" });
    
        try {
            const plano = await PlanoAssinatura.findOne({ where: { id } });
            if (!plano) return res.status(404).json({ msg: "Plano inexistente" });
    
            const decoded = jwt.verify(token, process.env.JWT_SECRET);
            const assinaturaExistente = await Assinatura.findOne({
                where: { usuarioId: decoded.id, planoId: id }
            });
    
            if (assinaturaExistente) {
                return res.status(400).json({ msg: "Usuário já possui essa assinatura!" });
            }

            // Ajustando a data de início e data de término no fuso horário de São Paulo
            const dataInicio = new Date();
            const offset = -3 * 60 * 60 * 1000; // Fuso horário de São Paulo (UTC-3)

            const dataInicioLocal = new Date(dataInicio.getTime() + offset);
            const dataFim = new Date(dataInicioLocal);
            dataFim.setDate(dataInicioLocal.getDate() + plano.duracao);

            const assinatura = await Assinatura.create({
                usuarioId: decoded.id,
                planoId: id,
                dataInicio: dataInicioLocal,
                dataFim, 
                statusAssinatura: "PENDENTE"
            });
    
            return res.status(201).json({ msg: "Assinatura criada com sucesso!", assinatura });
        } catch (error) {
            console.error(error);
            return res.status(500).json({ msg: "Erro no servidor!" });
        }
    },

    async visualizarAssinaturas(req, res) {
        const token = req.headers["x-access-token"];

        try {
            const decoded = jwt.verify(token, process.env.JWT_SECRET);

            const assinaturas = await Assinatura.findAll({
							where: { usuarioId: decoded.id },
							include: [
									{
											model: PlanoAssinatura,
											attributes: ['nome', 'valor', 'duracao', 'descricao'],
											include: [
                        {
                            model: Atletica,
                            attributes: ['nome']
                        }
                    ]
                }
            ]
        });
								
            if (!assinaturas) {
                return res.status(404).json({ msg: "Usuário não possui assinaturas!" });
            }

            for (const assinatura of assinaturas) {
                await verificarExpiracaoAssinatura(assinatura);
            }

						const assinaturasComDetalhes = assinaturas.map(assinatura => {
							const plano = assinatura.PlanoAssinatura;
							const atleticaNome = plano.Atletica ? plano.Atletica.nome : null;
							return {
									id: assinatura.id,
									planoId: assinatura.planoId,
									planoNome: plano.nome,
									planoValor: plano.valor,
									planoDuracao: plano.duracao,
									planoDescricao: plano.descricao,
									atleticaNome,
									usuarioId: assinatura.usuarioId,
									dataInicio: assinatura.dataInicio,
									dataFim: assinatura.dataFim,
									statusAssinatura: assinatura.statusAssinatura,
									createdAt: assinatura.createdAt,
									updatedAt: assinatura.updatedAt,
							};
					});

            return res.status(200).json({ assinaturas: assinaturasComDetalhes });
        } catch (error) {
            console.error(error);
            return res.status(500).json({ msg: "Erro no servidor!" });
        }
    },

    async selecionarAssinatura(req, res) {
        const { id } = req.params;
        const token = req.headers["x-access-token"];

        if (!id) {
            return res.status(400).json({ msg: "Id não fornecido!" });
        }

        try {
            const assinatura = await Assinatura.findByPk(id);
            if (!assinatura) {
                return res.status(404).json({ msg: "Assinatura não encontrada!" });
            }

            const decoded = jwt.verify(token, process.env.JWT_SECRET);
            if (assinatura.usuarioId !== decoded.id) {
                return res.status(401).json({ msg: "Usuário sem permissão de acesso!" });
            }

            await verificarExpiracaoAssinatura(assinatura);

            return res.status(200).json({ assinatura });
        } catch (error) {
            console.error(error);
            return res.status(500).json({ msg: "Erro no servidor!" });
        }
    },

    async cancelarAssinatura(req, res) {
        const { id } = req.params;
        const token = req.headers["x-access-token"];

        if (!id) {
            return res.status(400).json({ msg: "Id não fornecido!" });
        }

        try {
            const assinatura = await Assinatura.findByPk(id);
            if (!assinatura) {
                return res.status(404).json({ msg: "Assinatura não encontrada!" });
            }

            const decoded = jwt.verify(token, process.env.JWT_SECRET);
            if (assinatura.usuarioId !== decoded.id) {
                return res.status(401).json({ msg: "Usuário sem permissão de acesso!" });
            }

            await assinatura.update({
                statusAssinatura: "CANCELADA"
            });
            await assinatura.save();
            return res.status(200).json({ msg: "Assinatura cancelada!" });
        } catch (error) {
            console.error(error);
            return res.status(500).json({ msg: "Erro no servidor!" });
        }
    },
};
