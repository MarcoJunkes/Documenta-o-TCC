const ProdutoCarrinhoCompra = require("../models/ProdutoCarrinhoCompra");
const CarrinhoCompra = require("../models/CarrinhoCompra");
const Produto = require("../models/Produto");

const jwt = require("jsonwebtoken");

module.exports = {
    async addProduto(req, res) {
        const { id } = req.params;
        const { quantidade } = req.body;
        const token = req.headers["x-access-token"];
        
        if (!id) return res.status(400).json({ msg: "Produto não fornecido!" });
        if (!quantidade) return res.status(400).json({ msg: "Campo obrigatório não fornecido!" });
    
        try {
            const decoded = jwt.verify(token, process.env.JWT_SECRET);
    
            const produto = await Produto.findByPk(id);
            if (!produto) return res.status(404).json({ msg: "Produto não encontrado!" });
    
            const dataCriacao = new Date(new Date().toLocaleString("en-US", { timeZone: "America/Sao_Paulo" }));
            const offset = -3 * 60 * 60 * 1000;
            const dataLocal = new Date(dataCriacao.getTime() + offset);
    
            let carrinho = await CarrinhoCompra.findOne({
                where: {
                    usuarioId: decoded.id,
                    status: "ATIVO"
                }
            });
    
            if (!carrinho) {
                carrinho = await CarrinhoCompra.create({
                    usuarioId: decoded.id,
                    data: dataLocal,
                    status: "ATIVO",
                    valorTotal: produto.valor * quantidade
                });
            }
    
            if (carrinho.status === "ATIVO") {
                let produtoCarrinho = await ProdutoCarrinhoCompra.findOne({
                    where: {
                        carrinhoCompraId: carrinho.id,
                        produtoId: id
                    }
                });
    
                if (!produtoCarrinho) {
                    produtoCarrinho = await ProdutoCarrinhoCompra.create({
                        produtoId: id,
                        carrinhoCompraId: carrinho.id,
                        quantidade
                    });
                    await carrinho.update({
                        valorTotal: carrinho.valorTotal + produto.valor * quantidade 
                    });
                } else {
                    await produtoCarrinho.update({
                        quantidade: produtoCarrinho.quantidade + quantidade
                    });
                    await carrinho.update({
                        valorTotal: carrinho.valorTotal + produto.valor * quantidade
                    });
    
                    return res.status(200).json({ msg: "Produto atualizado com nova quantidade!" });
                }
    
                return res.status(201).json({ msg: "Produto inserido!", produtoCarrinho });
            }
        } catch (error) {
            console.error(error);
            return res.status(500).json({ msg: "Erro no servidor!" });
        }
    },
    
    async listarProdutos(req, res) {
        const token = req.headers["x-access-token"];
    
        try {
            const decoded = jwt.verify(token, process.env.JWT_SECRET);
    
            const carrinho = await CarrinhoCompra.findOne({
                where: {
                    usuarioId: decoded.id,
                    status: "ATIVO"
                }
            });
    
            if (!carrinho) {
                return res.status(201).json();
            }
    
            const produtos = await ProdutoCarrinhoCompra.findAll({
                where: { carrinhoCompraId: carrinho.id },
                include: [
                    {
                        model: Produto,
                        as: 'produto',
                        attributes: ['nome', 'valor']
                    }
                ]
            });
    
            if (!produtos || produtos.length === 0) {
                return res.status(404).json({ msg: "Carrinho não possui produtos!" });
            }

            const produtosComDetalhes = produtos.map((item) => {
                const produtoValor = item.produto?.valor || 0;
                const quantidade = item.quantidade || 0;
                const valorTotal = produtoValor * quantidade;
    
                return {
                    produtoId: item.produtoId,
                    carrinhoCompraId: item.carrinhoCompraId,
                    quantidade: item.quantidade,
                    valorUnitario: produtoValor,
                    valorTotal: valorTotal,
                    produto: {
                        nome: item.produto?.nome,
                        valor: produtoValor
                    }
                };
            });
    
            const valorTotalCarrinho = produtosComDetalhes.reduce((acc, item) => acc + item.valorTotal, 0);
    
            return res.status(200).json({
                produtos: produtosComDetalhes,
                valorTotalCarrinho: valorTotalCarrinho
            });
        } catch (error) {
            console.error(error);
            return res.status(500).json({ msg: "Erro no servidor!" });
        }
    },

    async removerProduto(req, res){
        const { id } = req.params;
        const token = req.headers["x-access-token"];
    
        if (!id) return res.status(400).json({ msg: "Id não fornecido!" });
    
        try {
            const decoded = jwt.verify(token, process.env.JWT_SECRET);
    
            const carrinho = await CarrinhoCompra.findOne({
                where: {
                    usuarioId: decoded.id,
                    status: "ATIVO"
                }
            });
    
            if (!carrinho) return res.status(404).json({ msg: "Erro ao buscar carrinho!" });
    
            const produto = await ProdutoCarrinhoCompra.findOne({
                where: {
                    produtoId: id,
                    carrinhoCompraId: carrinho.id
                }
            });
    
            if (!produto) return res.status(404).json({ msg: "Produto não encontrado!" });
    
            await produto.destroy();
    
            const produtosNoCarrinho = await ProdutoCarrinhoCompra.findAll({
                where: { carrinhoCompraId: carrinho.id }
            });
    
            const novoValorTotalCarrinho = produtosNoCarrinho.reduce((acc, item) => {
                const valorUnitario = item.produto?.valor || 0;
                const quantidadeProduto = item.quantidade || 0;
                return acc + (valorUnitario * quantidadeProduto);
            }, 0);
    
            await carrinho.update({
                valorTotal: novoValorTotalCarrinho
            });
    
            return res.status(200).json({
                msg: "Produto removido do carrinho!",
            });
        } catch (error) {
            console.error(error);
            return res.status(500).json({ msg: "Erro no servidor!" });
        }
    },

    async excluirCarrinho(req, res){
        const token = req.headers["x-access-token"];

        try{
            const decoded = jwt.verify(token, process.env.JWT_SECRET);

            const carrinho = await CarrinhoCompra.findOne({
                where: {
                    usuarioId: decoded.id,
                    status: "ATIVO"
                }
            });
            if(!carrinho) return res.status(404).json({msg: "Falha ao buscar carrinho!"});

            await ProdutoCarrinhoCompra.destroy({
                where: { 
                    carrinhoCompraId: carrinho.id, 
                }
            });
            
            await carrinho.destroy();

            return res.status(200).json({msg: "Carrinho deletado!"});
        }catch(error){
            console.error(error);
            return res.status(500).json({msg: "Erro no servidor!"});
        }
    }
}