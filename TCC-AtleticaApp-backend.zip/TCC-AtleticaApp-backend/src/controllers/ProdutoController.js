const Produto = require("../models/Produto");
const MembroAtletica = require("../models/MembroAtletica");
const Atletica = require("../models/Atletica");

const jwt = require("jsonwebtoken");
const AuthService = require("../services/authService");

function normalizeKeys(obj) { //essa função se mostrou necessárias, pois por algum motivo estava sendo adicionado um espaço ao lado do atributo de valor, o que impedia o funcionamento correto
    const normalized = {};
    for (const key in obj) {
        const trimmedKey = key.trim(); 
        normalized[trimmedKey] = obj[key]; 
    }
    return normalized;
}

module.exports = {
    async listarProdutos(req, res) {
        try {
            const produtos = await Produto.findAll();
            
            const produtosComAtletica = await Promise.all(
                produtos.map(async (produto) => {
                    const atletica = await Atletica.findOne({
                        where: { id: produto.atleticaId }
                    });
                    return {
                        ...produto.toJSON(), 
                        atleticaNome: atletica ? atletica.nome : null
                    };
                })
            );
    
            return res.status(200).json(produtosComAtletica);
        } catch (error) {
            console.log(error);
            return res.status(500).json({ msg: "Erro no servidor!" });
        }
    },
    

    async listarProdutosPorAtletica(req, res){
        const { id } = req.params;

        if(!id) return res.status(400).json({msg: "Id não fornecido!"});

        try{
						const produtoAtletica = await Produto.findAll({where: {atleticaId: id}});
            if (!produtoAtletica) return res.status(404).json({msg: "Falha ao buscar produto!"});

						const produto = await Promise.all(
							produtoAtletica.map(async (produtos) => {
							  const atletica = await Atletica.findOne({
									where: { id: produtos.atleticaId }
							});
							return {
									...produtos.toJSON(), 
									atleticaNome: atletica ? atletica.nome : null
							};
					})
			);
							
            return res.status(200).json({produto});
        }catch(error){
            console.error(error);
            return res.status(500).json({msg: "Erro no servidor!"});
        }
    },

    async addProduto(req, res){
        const { nome, valor, quantidade } = req.body;
        const token = req.headers["x-access-token"];

        if(!nome || !valor || !quantidade)
            return res.status(400).json({msg: "Campos obrigatórios não preenchidos!"});

        try{
            await AuthService.verificaPermissao(token, ["ADMIN"]);
        }catch(error){
            console.error(error || error.message);
            return res.status(401).json({msg: error.message});
        }

        try{
            const decoded = jwt.verify(token, process.env.JWT_SECRET);

            const membroAtletica = await MembroAtletica.findOne({where: {usuarioId: decoded.id}});
            if(!membroAtletica) return res.status(404).json({msg: "Erro ao buscar membro!"});

            const atletica = await Atletica.findOne({where: {id: membroAtletica.atleticaId}});
            if(!atletica) return res.status(404).json({msg: "Erro ao buscar atlética!"});

            const produtoExistente = await Produto.findOne({where: {nome: nome}});
            if(produtoExistente) return res.status(404).json({msg: "Produto já cadastrado!"});

            const imagem = req.file ? req.file.path : null;

            const produto = await Produto.create({
                atleticaId: atletica.id,
                nome,
                imagem,
                valor,
                quantidade
            });
            return res.status(201).json({msg: "Produto Cadastrado!", produto});
        }catch(error){
            console.error(error);
            return res.status(500).json({msg: "Erro no servidor!"});
        }
    },
    
    async editarProduto(req, res) {
        const { id } = req.params;
        let { nome, valor, quantidade } = normalizeKeys(req.body); // Normaliza as chaves
        const token = req.headers["x-access-token"];
    
        if (!id) return res.status(400).json({ msg: "Id não fornecido!" });
    
        try {
            await AuthService.verificaPermissao(token, ["ADMIN"]);
        } catch (error) {
            console.error(error || error.message);
            return res.status(401).json({ msg: error.message });
        }
    
        try {
            const decoded = jwt.verify(token, process.env.JWT_SECRET);

            const produto = await Produto.findByPk(id);
            if (!produto) return res.status(404).json({ msg: "Produto não encontrado!" });

            const membro = await MembroAtletica.findOne({
                where: {
                    usuarioId: decoded.id,
                    atleticaId: produto.atleticaId
                }
            });
            if(!membro) return res.status(401).json({msg: "Usuário sem permissão de acesso!"});
    
            const imagem = req.file ? req.file.path : produto.imagem;
    
            const dadosAtualizados = {};
            if (nome) dadosAtualizados.nome = nome;
            if (valor) dadosAtualizados.valor = valor;
            if (quantidade) dadosAtualizados.quantidade = quantidade;
            if (imagem) dadosAtualizados.imagem = imagem;
    
            await produto.update(dadosAtualizados);
            return res.status(200).json({ msg: "Dados atualizados!", produto });
        } catch (error) {
            console.error(error);
            return res.status(500).json({ msg: "Erro no servidor!" });
        }
    },

    async deletarProduto(req, res){
        const { id } = req.params;
        const token = req.headers["x-access-token"];

        if(!id) return res.status(400).json({msg: "Id não fornecido!"});

        try{
            await AuthService.verificaPermissao(token, ["ADMIN"]);
        }catch(error){
            console.error(error || error.message);
            return res.status(401).json({msg: error.message});
        }

        try{
            const decoded = jwt.verify(token, process.env.JWT_SECRET);

            const produto = await Produto.findByPk(id);
            if(!produto) return res.status(404).json({msg: "Produto não encontrado!"});

            const membro = await MembroAtletica.findOne({
                where: {
                    usuarioId: decoded.id,
                    atleticaId: produto.atleticaId
                }
            });
            if(!membro) return res.status(401).json({msg: "Usuário sem permissão de acesso!"});

            await produto.destroy();
            return res.status(200).json({msg: "Produto deletado com sucesso!"});
        }catch(error){
            console.error(error);
            return res.status(500).json({msg: "Erro no servidor!"});
        }
    }
}