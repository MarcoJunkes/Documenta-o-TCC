const Evento = require("../models/Evento");
const Usuario = require("../models/Usuario");
const Atletica = require("../models/Atletica");
const UsuarioEvento = require("../models/UsuarioEvento");
const AuthService = require("../services/authService");

const jwt = require("jsonwebtoken");

module.exports = {
    async criarEvento(req, res) {
        const token = req.headers["x-access-token"];

        try {
            await AuthService.verificaPermissao(token, ["ADMIN", "master"]);
        } catch (error) {
            console.error(error.message);
            return res.status(401).json({ msg: error.message });
        }

        try {
            const { data, hora, endereco, titulo, descricao, linkPlataformaIngressos, qtdeVagas, ingresso, statusEvento, modalidade, atleticaId, atleticaName } = req.body;

            console.log("dados:", req.body);
            if (!data || !hora || !endereco || !titulo || !descricao || !statusEvento || !modalidade || !atleticaId || !atleticaName) {
                return res.status(400).json({ msg: "Dados obrigatórios não fornecidos" });
            }

            const evento = await Evento.create({ data, hora, endereco, titulo, descricao, linkPlataformaIngressos, qtdeVagas, ingresso, statusEvento, modalidade, atleticaId, atleticaName });

            return res.status(201).json(evento);
        } catch (error) {
            console.error(error);
            return res.status(500).json({ msg: "Erro ao criar evento, verifique as informações" });
        }
    },

    async excluirEvento(req, res) {
        const token = req.headers["x-access-token"];

        try {
            await AuthService.verificaPermissao(token, ["ADMIN", "master"]);
        } catch (error) {
            console.error(error.message);
            return res.status(401).json({ msg: error.message });
        }

        try {
            const { id } = req.params;

            const evento = await Evento.findByPk(id);

            if (!evento) {
                return res.status(404).json({ msg: "Evento não encontrado" });
            }

            await evento.destroy();

            return res.status(200).json({ msg: "Evento removido com sucesso." });
        } catch (error) {
            console.error("Erro ao remover o evento:", error);
            return res.status(500).json({ msg: "Erro ao remover o evento.", error });
        }
    },

		async listarEvento(req, res) {
			const token = req.headers["x-access-token"];
	
			try {
					const eventos = await Evento.findAll({
							attributes: ['id', 'data', 'hora', 'endereco', 'titulo', 'descricao', 'linkPlataformaIngressos', 'qtdeVagas', 'ingresso', 'statusEvento', 'modalidade', 'atleticaId', 'atleticaName', 'createdAt', 'updatedAt']
					});
					const decoded = jwt.verify(token, process.env.JWT_SECRET);
	
					return res.status(200).json(eventos);
			} catch (error) {
					console.error("Erro ao listar eventos", error);
	
					return res.status(500).json({ msg: "Erro ao listar eventos", error: error.message });
			}
	},

    async selecionarEvento(req, res) {
        const token = req.headers["x-access-token"];

        try {
            const { id } = req.params;
            const decoded = jwt.verify(token, process.env.JWT_SECRET);
            const evento = await Evento.findByPk(id);

            if (!evento) {
                return res.status(404).json({ msg: "Evento não encontrado." });
            }

            return res.status(200).json(evento);
        } catch (error) {
            console.error("Erro ao selecionar o evento: ", error);
            return res.status(500).json({ msg: "Erro ao selecionar o evento: ", error });
        }
    },

    async participarEvento(req, res) {
        const token = req.headers["x-access-token"];

        try {
            const { id } = req.params;

            const decoded = jwt.verify(token, process.env.JWT_SECRET);

            const evento = await Evento.findByPk(id);
            if (!evento) {
                return res.status(404).json({ msg: "Evento não encontrado" });
            }

            const inscricaoExistente = await UsuarioEvento.findOne({
                where: { usuarioId: decoded.id, eventoId: id }
            });

            if (inscricaoExistente) {
                return res.status(400).json({ msg: "Usuário já está inscrito neste evento." });
            }

            const inscricao = await UsuarioEvento.create({ usuarioId: decoded.id, eventoId: id });

            return res.status(201).json({ msg: "Inscrição realizada com sucesso", inscricao });
        } catch (error) {
            console.error("Erro ao realizar inscrição no evento: ", error);
            return res.status(500).json({ msg: "Erro ao realizar inscrição no evento", error });
        }
    },

    async cancelarParticipacao(req, res) {
        const token = req.headers["x-access-token"];

        try {
            const decoded = jwt.verify(token, process.env.JWT_SECRET);
            const usuarioId = decoded.id;

            const { id } = req.params;

            const inscricao = await UsuarioEvento.findOne({
                where: { usuarioId, eventoId: id }
            });

            if (!inscricao) {
                return res.status(404).json({ msg: "Usuário não está inscrito no evento ou evento não existe." });
            }
            await inscricao.destroy();

            return res.status(200).json({ msg: "Participação no evento cancelada com sucesso!" });
        } catch (error) {
            console.error("Erro ao cancelar a participação no evento:", error);
            return res.status(500).json({ msg: "Erro ao cancelar a participação no evento", error });
        }
    },

    async meusEventos(req, res) {
        const token = req.headers["x-access-token"];

        try {
            const decoded = jwt.verify(token, process.env.JWT_SECRET);
            const usuarioId = decoded.id;

            const eventos = await UsuarioEvento.findAll({
                where: { usuarioId },
                include: [{
                    model: Evento,
                    attributes: ['id', 'data', 'hora', 'endereco', 'titulo', 'descricao', 'linkPlataformaIngressos', 'qtdeVagas', 'statusEvento', 'modalidade', 'atleticaId', 'atleticaName']
                }]
            });

            const eventosDetalhes = eventos.map(inscricao => inscricao.Evento);

            return res.status(200).json(eventosDetalhes);
        } catch (error) {
            console.error("Erro ao listar eventos inscritos:", error);
            return res.status(500).json({ msg: "Erro ao listar eventos inscritos", error });
        }
    },

    async listarInscritos(req, res) {
			const token = req.headers["x-access-token"];

			try {
					await AuthService.verificaPermissao(token, ["ADMIN", "master"]);
			} catch (error) {
					console.error(error.message);
					return res.status(401).json({ msg: error.message });
			}

			try {
					const { id } = req.params;

					const evento = await Evento.findByPk(id, {
							include: [{
									model: Usuario,
									through: { attributes: [] }
							}]
					});

					if (!evento) {
							return res.status(404).json({ msg: "Evento não encontrado" });
					}

					return res.status(200).json(evento.Usuarios);
			} catch (error) {
					console.error("Erro ao listar inscritos no evento:", error);
					return res.status(500).json({ msg: "Erro ao listar inscritos no evento", error });
			}
	}
};