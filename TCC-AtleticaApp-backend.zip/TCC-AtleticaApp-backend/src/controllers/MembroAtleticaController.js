const MembroAtletica = require("../models/MembroAtletica");
const Usuario = require("../models/Usuario");
const Atletica = require("../models/Atletica");
const Curso = require("../models/Curso");
const AuthService = require("../services/authService");

module.exports = {
    async listarMembros(req, res) {

        const token = req.headers["x-access-token"]    

        try {
            await AuthService.verificaPermissao(token, ["ADMIN", "master"]);
        }
        catch(error){
            console.error(error.message); 
            return res.status(401).json({ msg: error.message })
        }

        try {
          const { atleticaId } = req.params; //para listar os membros por atlética


          const membros = await MembroAtletica.findAll({
            where: { atleticaId },
            include: [
              {
                model: Usuario, 
                attributes: ['nome', 'email'], 
              },
            ],
          });

          res.status(200).json(membros);
        } catch (error) {
          console.error('Erro ao listar membros:', error);
          res.status(500).json({ msg: 'Erro ao listar os membros.' });
        }
      },

      async adicionarMembro(req, res) {
        const token = req.headers["x-access-token"];    
    
        try {
            await AuthService.verificaPermissao(token, ["ADMIN", "master"]);
        } catch (error) {
            console.error(error.message); 
            return res.status(401).json({ msg: error.message });
        }
    
        const { email, administrador, atleticaId } = req.body;
    
        try {
            const usuario = await Usuario.findOne({ where: { email } });
    
            if (!usuario) {
                return res.status(404).json({ msg: "Usuário não encontrado" });
            }
    
            const atletica = await Atletica.findOne({ 
                where: { id: atleticaId } //busca atlética pelo ID
            });
    
            if (!atletica) {
                return res.status(404).json({ msg: "Atlética não encontrada." });
            }
    
            const cursoIdUsuario = usuario.cursoId;
            const atleticaCursos = await atletica.getCursos({ where: { id: cursoIdUsuario } });
    
            if (atleticaCursos.length === 0) {
                return res.status(403).json({ msg: "O curso do usuário não está associado a essa atlética." });
            }
    
            const membroExistente = await MembroAtletica.findOne({
                where: { usuarioId: usuario.id, atleticaId: atletica.id }
            });
    
            if (membroExistente) {
                return res.status(409).json({ msg: "Usuário já é membro da atlética" });
            }
    
            const novoMembro = await MembroAtletica.create({
                usuarioId: usuario.id,
                administrador: administrador || false,
								nome: usuario.nome,
								email: usuario.email,
                atleticaId: atletica.id
            });
    
            if (administrador) {
                usuario.tipo = "ADMIN";
                await usuario.save();
            }
    
						res.status(200).json({ 
							msg: "Membro adicionado com sucesso.", 
							novoMembro: {
									...novoMembro.toJSON(),
									nome: usuario.nome,
									email: usuario.email
							}
					});
        } catch (error) {
            console.log("Erro:", error.message); 
            res.status(500).json({ msg: "Erro ao adicionar o membro: usuário não existe", erro: error.message }); 
        }
    },
    

    async editarMembro(req, res) {
        const token = req.headers["x-access-token"];
    
        try {
            await AuthService.verificaPermissao(token, ["ADMIN", "master"]);
        } catch (error) {
            console.error("Erro de autenticação:", error.message); 
            return res.status(401).json({ msg: error.message });
        }
        
        const { email } = req.params;
        const { administrador } = req.body;
    

        try {
            const usuario = await Usuario.findOne({ where: { email } });
    
            if (!usuario) {
                console.log("Usuário não encontrado:", email);
                return res.status(404).json({ msg: "Usuário não encontrado." });
            }
            
            const membro = await MembroAtletica.findOne({
                where: { usuarioId: usuario.id }
            });
    
            if (!membro) {
                console.log("Membro não encontrado para o usuário de ID:", usuario.id);
                return res.status(404).json({ msg: "Membro não encontrado." });
            }
    
            console.log("Membro encontrado com status de administrador:", membro.administrador);

            if (membro.administrador === true && administrador === false) {
                //console.log("Rebaixando para membro");

                try {
                    membro.administrador = false;
                    await membro.save();

                } catch (error) {
                    return res.status(500).json({ msg: "Erro ao atualizar o membro"});
                }
    
                try {
                    usuario.tipo = "ESTUDANTE"; //atualiza o tipo
                    await usuario.save();

                } catch (error) {
                    return res.status(500).json({ msg: "Erro ao atualizar o tipo de usuário"});
                }
                
    
            return res.status(200).json({ msg: "Membro atualizado com sucesso", membro });
        } else if (membro.administrador === false && administrador === true) {
            console.log("Atualizando membro para administrador");

            try {
                membro.administrador = true;
                await membro.save();
                console.log("Membro atualizado: administrador = true");
            }   
                catch (error) {
                    console.error("Erro ao salver membro como administrador", error.message);
                    return res.status(500).json({ msg: "Erro ao atualizar o membro"});
                }

            try {
                usuario.tipo = "ADMIN";
                await usuario.save();
                console.log("TIpo de usuário atualizado para ADMIN");
            }
                catch (error) {
                    console.error("Erro ao salvar o tipo de usuário como ADMIN", error.message);
                    return res.status(500).json({ msg: "Erro ao atualizar o tipo do usuário"});
                }

                    return res.status(200).json({ msg: "Membro atualizado com sucesso", membro});
        }
                else {
                    console.log("Nenhuma alteração necessária para o status de administrador");
                    return res.status(200).json({ msg: "Nenhuma alteração necessária.", membro});
                }
            }   catch (error) {
                console.error("Erro ao atualizar membro", error.message);
                return res.status(500).json({ msg: "Falha ao atualizar o membro"});
            }

         },

    async removerMembro(req, res) { //remove QUALQUER membro, seja ele admin ou não

        const token = req.headers["x-access-token"]    

        try {
            await AuthService.verificaPermissao(token, ["ADMIN", "master"]);
        }
        catch(error){
            console.error(error.message); 
            return res.status(401).json({ msg: error.message })
        }

        const { email } = req.params;

        try {
            const usuario = await Usuario.findOne({ where: { email }});

            if(!usuario) {
                return res.status(404).json({ msg: "Usuário não encontrado."});
            }

            const membro = await MembroAtletica.findOne({
                where: { usuarioId: usuario.id },
            });

            if (!membro) {
                
                return res.status(404).json({ msg: "Membro não encontrado"});
            }

            const wasAdmin = membro.administrador;
            await membro.destroy();

            if (wasAdmin) {
                usuario.tipo = "ESTUDANTE";
                await usuario.save();
            }

            return res.status(200).json({ msg: "Membro removido com sucesso."});
        }
            catch (error) {
                
                return res.status(500).json({ msg: "Falha ao remover membro." });
            }
    }
};
