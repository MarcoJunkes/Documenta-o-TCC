const Curso = require("../models/Curso");

module.exports = {
    async retornarCursos(req, res){
        const cursos = await Curso.findAll({
            order: [["nome", "ASC"]],
        }).catch((error) => {
            res.status(500).json({msg: "Falha na conexão.", error})
        });
        if(cursos) res.status(200).json({cursos});
        else res.status(404).json({msg: "Não foi possível encontrar cursos"});
    },
}