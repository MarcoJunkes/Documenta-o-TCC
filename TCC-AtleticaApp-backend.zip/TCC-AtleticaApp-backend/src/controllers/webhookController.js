const stripe = require('stripe')(process.env.STRIPE_SECRET_KEY);
const Assinatura = require('../models/Assinatura');
const Pagamento = require('../models/Pagamento');
const PagamentoAssinatura = require('../models/PagamentoAssinatura');
const Pedido = require('../models/Pedido');
const PagamentoPedido = require('../models/PagamentoPedido');

module.exports = {
    async handleWebhook(req, res) {
        const sig = req.headers['stripe-signature'];

        let event;
        try {
            // Verifica se o evento enviado pelo Stripe é válido 
            event = stripe.webhooks.constructEvent(req.rawBody, sig, process.env.STRIPE_WEBHOOK_SECRET);
        } catch (err) {
            console.error(`Erro ao verificar webhook: ${err.message}`);
            return res.status(400).send(`Webhook Error: ${err.message}`);
        }        

        switch (event.type) {
            case 'checkout.session.completed':
                const session = event.data.object;
                await handleCheckoutSessionCompleted(session);
                await handleCheckoutSessionCompletedOrder(session);
                break;
            default:
                console.log(`Evento do Stripe não tratado: ${event.type}`);
        }

        res.json({ received: true });
    }
};

// Função auxiliar para lidar com a finalização de sessão de checkout
async function handleCheckoutSessionCompleted(session) {
    const assinaturaId = session.metadata.assinaturaId;
    const valorPago = session.amount_total / 100;

    try {
        if (assinaturaId) {
            const assinatura = await Assinatura.findByPk(assinaturaId);
            if (!assinatura) {
                console.error(`Assinatura não encontrada para ID: ${assinaturaId}`);
                return;
            }

            assinatura.statusAssinatura = 'PAGA';
            await assinatura.save();

            const dataPagamento = new Date(new Date().toLocaleString("en-US", { timeZone: "America/Sao_Paulo" }));
            const offset = -3 * 60 * 60 * 1000;
            const dataPagamentoLocal = new Date(dataPagamento.getTime() + offset);

            const pagamento = await Pagamento.create({
                descricao: `Pagamento do plano ${assinatura.planoId}`,
                valor: valorPago,
                data: dataPagamentoLocal,
                forma: 'card'
            });

            await PagamentoAssinatura.create({
                assinaturaId: assinatura.id,
                pagamentoId: pagamento.id
            });

            console.log(`Assinatura ${assinaturaId} atualizada para PAGA e pagamento registrado.`);
        }
    } catch (error) {
        console.error("Erro ao processar pagamento:", error);
    }
}

async function handleCheckoutSessionCompletedOrder(session) {
    const pedidoId = session.metadata.pedidoId;
    const valorPago = session.amount_total / 100;

    try {
        if (pedidoId) {
            const pedido = await Pedido.findByPk(pedidoId);
            if (!pedido) {
                console.error(`Assinatura não encontrada para ID: ${pedidoId}`);
                return;
            }

            pedido.status = 'CONCLUIDO';
            await pedido.save();

            const dataPagamento = new Date(new Date().toLocaleString("en-US", { timeZone: "America/Sao_Paulo" }));
            const offset = -3 * 60 * 60 * 1000;
            const dataPagamentoLocal = new Date(dataPagamento.getTime() + offset);

            const pagamento = await Pagamento.create({
                descricao: `Pagamento do pedido ${pedidoId}`,
                valor: valorPago,
                data: dataPagamentoLocal,
                forma: 'card'
            });

            console.log("PEDIDO ID: ", pedido.id);
            await PagamentoPedido.create({
                idPedido: pedido.id,
                pagamentoId: pagamento.id
            });

            console.log(`Pedido ${pedidoId} atualizado para CONCLUIDO e pagamento registrado.`);
        }
    } catch (error) {
        console.error("Erro ao processar pagamento:", error);
    }
}
