const Assinatura = require("../models/Assinatura");
const Plano = require("../models/PlanoAssinatura");
const Pedido = require("../models/Pedido");

const realizarPagamentoService = require("../services/pagamentoService");
const jwt = require("jsonwebtoken");

module.exports = {
    async realizarPagamento(req, res) {
        const { id } = req.params;
        const token = req.headers["x-access-token"];

        if (!id) return res.status(400).json({ msg: "Id não fornecido!" });
    
        try {
            const decoded = jwt.verify(token, process.env.JWT_SECRET);

            const assinatura = await Assinatura.findByPk(id);
            if (!assinatura) return res.status(404).json({ msg: "Assinatura não encontrada!" });
            if (assinatura.statusAssinatura === "CANCELADA")
                return res.status(404).json({msg: "Assinatura Cancelada!"});
            if (assinatura.statusAssinatura === "PAGA")
                return res.status(404).json({msg: "Assinatura já está paga!"});

            const plano = await Plano.findOne({ where: { id: assinatura.planoId } });
            if (!plano) return res.status(404).json({ msg: "Plano não encontrado!" });

            if (assinatura.usuarioId !== decoded.id) {
                return res.status(401).json({ msg: "Usuário sem permissão de acesso!" });
            }
    
            const descricao = plano.nome;
            const valor = plano.valor;
            const forma = 'card'; 
    
            const pagamentoResponse = await realizarPagamentoService({
                descricao, valor, forma, metadata: { assinaturaId: id }
            });
    
            if (pagamentoResponse.error) return res.status(500).json({ msg: "Erro ao processar pagamento!" });
    
            // Retorna a URL de checkout ao cliente
            return res.status(200).json({ url: pagamentoResponse.url });
        } catch (error) {
            console.error(error);
            return res.status(500).json({ msg: "Erro no servidor!" });
        }
    },

    async realizarPagamentoPedido(req, res){
        const { id } = req.params;
        const token = req.headers["x-access-token"];

        if (!id) return res.status(400).json({ msg: "Id não fornecido!" });
    
        try {
            const decoded = jwt.verify(token, process.env.JWT_SECRET);

            const pedido = await Pedido.findByPk(id);
            if(!pedido) return res.status(400).json({msg: "Falha ao buscar Pedido!"});

            if(pedido.status === 'CANCELADO')
                return res.status(400).json({msg: "Não é possível realizar o pagamento de um pedido cancelado!"});
            else if(pedido.status === 'CONCLUIDO')
                return res.status(400).json({msg: "Pedido já está pago!"});

            if(pedido.usuarioId !== decoded.id)
                return res.status(401).json({msg: "Usuário sem permissão de acesso!"});

            const descricao = pedido.id;
            const valor = pedido.valorTotal;
            const forma = 'card'; 
    
            const pagamentoResponse = await realizarPagamentoService({
                descricao, valor, forma, metadata: { pedidoId: id }
            });
    
            if (pagamentoResponse.error) return res.status(500).json({ msg: "Erro ao processar pagamento!" });
    
            return res.status(200).json({ url: pagamentoResponse.url });
        } catch (error) {
            console.error(error);
            return res.status(500).json({ msg: "Erro no servidor!" });
        }
    }
    
}
