const Pedido = require("../models/Pedido");
const CarrinhoCompra = require("../models/CarrinhoCompra");
const ProdutoCarrinhoCompra = require("../models/ProdutoCarrinhoCompra");
const Produto = require("../models/Produto");
const MembroAtletica = require("../models/MembroAtletica");
const Usuario = require("../models/Usuario");

const jwt = require("jsonwebtoken");
const { sendEmail } = require("../services/emailService");

module.exports = {
    async criarPedido(req, res) {
        const token = req.headers["x-access-token"];

        try {
            const decoded = jwt.verify(token, process.env.JWT_SECRET);
            const usuario = await Usuario.findOne({ where: { id: decoded.id } });

            if (!usuario) return res.status(400).json({ msg: "Falha ao buscar usuário!" });

            const carrinho = await CarrinhoCompra.findOne({
                where: {
                    status: 'ATIVO',
                    usuarioId: usuario.id
                }
            });

            if (!carrinho) return res.status(400).json({ msg: "Falha ao buscar carrinho!" });

            const produtosCarrinho = await ProdutoCarrinhoCompra.findAll({
                where: { carrinhoCompraId: carrinho.id },
                include: [
                    {
                        model: Produto,
                        as: 'produto',
                        attributes: ['id', 'nome', 'valor', 'quantidade', 'atleticaId']
                    }
                ]
            });

            if (!produtosCarrinho || produtosCarrinho.length === 0)
                return res.status(400).json({ msg: "Carrinho vazio ou inválido!" });

            let valorTotalCarrinho = 0;
            const produtosPorAtletica = {};

            for (const itemCarrinho of produtosCarrinho) {
                const produto = await Produto.findOne({ where: { id: itemCarrinho.produtoId } });

                if (!produto)
                    return res.status(400).json({ msg: `Produto com ID ${itemCarrinho.produtoId} não encontrado!` });

                if (produto.quantidade >= itemCarrinho.quantidade) {
                    produto.quantidade -= itemCarrinho.quantidade;
                    await produto.save();

                    valorTotalCarrinho += produto.valor * itemCarrinho.quantidade;

                    if (!produtosPorAtletica[produto.atleticaId]) {
                        produtosPorAtletica[produto.atleticaId] = [];
                    }
                    produtosPorAtletica[produto.atleticaId].push({
                        nome: produto.nome,
                        quantidade: itemCarrinho.quantidade,
                        valor: produto.valor,
                    });
                } else {
                    return res.status(400).json({
                        msg: `Quantidade insuficiente para o produto ${produto.nome}!`,
                    });
                }
            }

            const dataCriacao = new Date(
                new Date().toLocaleString("en-US", { timeZone: "America/Sao_Paulo" })
            );
            const offset = -3 * 60 * 60 * 1000;
            const dataLocal = new Date(dataCriacao.getTime() + offset);

            await Pedido.create({
                idCarrinho: carrinho.id,
                usuarioId: decoded.id,
                data: dataLocal,
                status: 'PENDENTE',
                valorTotal: valorTotalCarrinho
            });

            await carrinho.update({
                status: 'INATIVO'
            });

            for (const atleticaId in produtosPorAtletica) {
                const administradores = await MembroAtletica.findAll({
                    where: { atleticaId, administrador: true }
                });

                const adminIds = administradores.map(admin => admin.usuarioId);

                const usuarios = await Usuario.findAll({
                    where: { id: adminIds },
                    attributes: ['email']
                });

                const produtos = produtosPorAtletica[atleticaId].map((p) =>
                    `- ${p.nome}: ${p.quantidade} unidade(s) a R$${p.valor.toFixed(2)} cada.`
                ).join('\n');

                const mensagem = `
                Olá!

                Um pedido foi realizado com os seguintes detalhes:

                Comprador: ${usuario.nome}
                Telefone: ${usuario.telefone}
                Data do Pedido: ${dataLocal}

                Produtos adquiridos:
                ${produtos}

                Atenciosamente,
                Equipe de Vendas
                `;

                for (const usuario of usuarios) {
                    await sendEmail(
                        usuario.email,
                        "Produtos Vendidos",
                        mensagem
                    );
                }
            }

            await sendEmail(
                usuario.email,
                "Pedido Confirmado!",
                "Olá! Estamos enviando este E-mail para informar que seu pedido foi confirmado. Para mais detalhes, acesse o aplicativo!"
            );

            return res.status(200).json({ msg: "Pedido criado com sucesso!" });
        } catch (error) {
            console.error(error);
            return res.status(500).json({ msg: "Erro no servidor!" });
        }
    },

    async listarPedidos(req, res) {
        const token = req.headers["x-access-token"];

        try {
            const decoded = jwt.verify(token, process.env.JWT_SECRET);
            const usuario = await Usuario.findOne({ where: { id: decoded.id } });

            if (!usuario) return res.status(400).json({ msg: "Usuário não encontrado!" });

            const pedidos = await Pedido.findAll({
                where: { usuarioId: usuario.id },
                order: [
                    [Pedido.sequelize.literal(`
                        CASE 
                            WHEN status = 'PENDENTE' THEN 1
                            WHEN status = 'CONCLUIDO' THEN 2
                            WHEN status = 'CANCELADO' THEN 3
                            ELSE 4
                        END
                    `), 'ASC'],
                    ['data', 'DESC']
                ]
            });

            if (!pedidos || pedidos.length === 0)
                return res.status(202).json(pedidos);

            const pedidosFormatados = pedidos.map((pedido) => {
                return {
                    id: pedido.id,
                    status: pedido.status,
                    valorTotal: pedido.valorTotal.toFixed(2),
                    data: pedido.data.toLocaleString('pt-BR'),
                    descricao: `Pedido #${pedido.id} - Status: ${pedido.status} - Valor Total: R$${pedido.valorTotal.toFixed(
                        2
                    )} - Data: ${pedido.data.toLocaleString('pt-BR')}`
                };
            });

            return res.status(200).json(pedidosFormatados);
        } catch (error) {
            console.error(error);
            return res.status(500).json({ msg: "Erro ao listar pedidos!" });
        }
    },

    async cancelarPedido(req, res) {
        const token = req.headers["x-access-token"];
        const { pedidoId } = req.params;

        try {
            const decoded = jwt.verify(token, process.env.JWT_SECRET);
            const usuario = await Usuario.findOne({ where: { id: decoded.id } });

            if (!usuario) return res.status(400).json({ msg: "Usuário não encontrado!" });

            const pedido = await Pedido.findOne({
                where: {
                    id: pedidoId,
                    usuarioId: usuario.id
                }
            });

            if (!pedido) return res.status(400).json({ msg: "Pedido não encontrado!" });

            if (pedido.status !== "PENDENTE") {
                return res.status(400).json({ msg: "O pedido não pode ser cancelado, pois não está em status PENDENTE!" });
            }

            await pedido.update({ status: 'CANCELADO' });

            await sendEmail(
                usuario.email,
                "Pedido Cancelado",
                `Olá, ${usuario.nome}!\n\nO seu pedido com ID #${pedido.id} foi cancelado com sucesso.\n\nAtenciosamente, Equipe de Vendas.`
            );

            const produtosCarrinho = await ProdutoCarrinhoCompra.findAll({
                where: { carrinhoCompraId: pedido.idCarrinho },
                include: [
                    {
                        model: Produto,
                        as: 'produto',
                        attributes: ['id', 'nome', 'atleticaId', 'valor']
                    }
                ]
            });
            const produtosPorAtletica = {};
            for (const itemCarrinho of produtosCarrinho) {
                const produto = itemCarrinho.produto;
                if (!produtosPorAtletica[produto.atleticaId]) {
                    produtosPorAtletica[produto.atleticaId] = [];
                }
                produtosPorAtletica[produto.atleticaId].push({
                    nome: produto.nome,
                    valor: produto.valor,
                });
            }

            for (const atleticaId in produtosPorAtletica) {
                const administradores = await MembroAtletica.findAll({
                    where: { atleticaId, administrador: true }
                });

                const adminIds = administradores.map(admin => admin.usuarioId);

                const usuarios = await Usuario.findAll({
                    where: { id: adminIds },
                    attributes: ['email']
                });

                const produtos = produtosPorAtletica[atleticaId].map((p) =>
                    `- ${p.nome}: R$${p.valor.toFixed(2)}`
                ).join('\n');

                const mensagem = `
                    Olá!

                    O seguinte pedido foi cancelado:

                    Comprador: ${usuario.nome}
                    Telefone: ${usuario.telefone}
                    Data do Pedido: ${pedido.data.toLocaleString('pt-BR')}
                    Status do Pedido: CANCELADO

                    Produtos adquiridos:
                    ${produtos}
                `;

                for (const admin of usuarios) {
                    await sendEmail(
                        admin.email,
                        "Pedido Cancelado",
                        mensagem
                    );
                }
            }

            return res.status(200).json({ msg: "Pedido cancelado com sucesso!" });
        } catch (error) {
            console.error(error);
            return res.status(500).json({ msg: "Erro ao cancelar pedido!" });
        }
    },

    async selecionarPedido(req, res) {
        const token = req.headers["x-access-token"];
        const { pedidoId } = req.params;
    
        try {
            const decoded = jwt.verify(token, process.env.JWT_SECRET);
            const usuario = await Usuario.findOne({ where: { id: decoded.id } });
    
            if (!usuario) return res.status(400).json({ msg: "Usuário não encontrado!" });
    
            const pedido = await Pedido.findOne({
                where: {
                    id: pedidoId,
                    usuarioId: usuario.id
                }
            });
    
            if (!pedido) return res.status(404).json({ msg: "Pedido não encontrado!" });
    
            const produtosCarrinho = await ProdutoCarrinhoCompra.findAll({
                where: { carrinhoCompraId: pedido.idCarrinho },
                include: [
                    {
                        model: Produto,
                        as: 'produto',
                        attributes: ['id', 'nome', 'valor', 'quantidade', 'atleticaId']
                    }
                ]
            });

            const produtos = produtosCarrinho.map((item) => {
                return {
                    nome: item.produto.nome,
                    valor: item.produto.valor.toFixed(2),
                    quantidade: item.quantidade,
                    atleticaId: item.produto.atleticaId
                };
            });

            const pedidoDetalhado = {
                id: pedido.id,
                status: pedido.status,
                valorTotal: pedido.valorTotal.toFixed(2),
                data: pedido.data.toLocaleString('pt-BR'),
                descricao: `Pedido #${pedido.id} - Status: ${pedido.status} - Valor Total: R$${pedido.valorTotal.toFixed(2)} - Data: ${pedido.data.toLocaleString('pt-BR')}`,
                produtos: produtos
            };
    
            return res.status(200).json(pedidoDetalhado);
        } catch (error) {
            console.error(error);
            return res.status(500).json({ msg: "Erro ao selecionar o pedido!" });
        }
    }
    
};
