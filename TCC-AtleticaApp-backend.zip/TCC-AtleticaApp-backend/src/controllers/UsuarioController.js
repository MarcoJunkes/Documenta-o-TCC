const Usuario = require("../models/Usuario");
const Curso = require("../models/Curso");
const jwt = require("jsonwebtoken");
const bcrypt = require("bcrypt");
const { sendEmail } = require("../services/emailService");
const MembroAtletica = require("../models/MembroAtletica");
const Atletica = require("../models/Atletica");
const Assinatura = require("../models/Assinatura");
const CarrinhoCompra = require("../models/CarrinhoCompra");
const Pedido = require("../models/Pedido");
const Evento = require("../models/Evento");

function generateToken(payload) {
    const token = jwt.sign(payload, process.env.JWT_SECRET, {
        expiresIn: 82800, // expira em 24h
    });
    return token;
}

const emailRegex = /^[a-zA-Z0-9._%+-]+@ufpr\.br$/;

function generateVerificationCode() {
    return Math.floor(100000 + Math.random() * 900000).toString(); 
}

module.exports = {
    async authentication(req, res) {
        const { email, senha } = req.body;
   
        if (!email || !senha) {
            return res.status(400).json({ msg: "Campos obrigatórios não preenchidos!" });
        }
    
        try {
            const usuario = await Usuario.findOne({
                where: { email },
                include: [
                    { model: Curso },
                    { model: Assinatura },
                    { model: CarrinhoCompra },
                    { model: Pedido },
                    { model: Evento, through: { attributes: [] } }
                ]
            });
            if (!usuario) {
                return res.status(401).json({ msg: "Usuário ou senha inválidos!" });
            }
    
						const membroAtletica = await MembroAtletica.findOne({ where: { usuarioId: usuario.id } });
						const atletica = membroAtletica ? await Atletica.findOne({ where: { id: membroAtletica.atleticaId } }) : null;
            const senhaValida = await bcrypt.compare(senha, usuario.senha);
    
            if (senhaValida) {
                const token = generateToken({ id: usuario.id });
    
                return res.status(200).json({
                    msg: "Autenticado com sucesso!",
                    token,
                    tipo: usuario.tipo,
                    curso: usuario.Curso ? usuario.Curso.nome : null,
                    assinaturas: usuario.Assinaturas,
                    carrinhos: usuario.CarrinhoCompras,
                    pedidos: usuario.Pedidos,
                    eventos: usuario.Eventos,
                    atletica: membroAtletica ? membroAtletica.atleticaId : null,
										atleticaNome: atletica ? atletica.nome : null,
                    usuarioId: usuario.id,
                    usuarioNome: usuario.nome
                });
            } 

            return res.status(401).json({ msg: "Usuário ou senha inválidos!" });
    
        } catch (error) {
            return res.status(500).json({ msg: "Erro no servidor", error });
        }
    },
    
    async enviarCodigoVerificacao(req, res) {
        const { email, action } = req.body;

        if (!email || !action) return res.status(400).json({ msg: "Campos obrigatórios não preenchidos" });

        if (!emailRegex.test(email)) {
            return res.status(422).json({ msg: "O email deve ser @ufpr.br" });
        }

        try {
            if (action === "cadastro") {
                const usuarioExistente = await Usuario.findOne({ where: { email } });
                if (usuarioExistente) {
                    return res.status(409).json({ msg: "Usuário já existente!" });
                }
            } else if (action === "recSenha") {
                const usuarioExistente = await Usuario.findOne({ where: { email } });
                if (!usuarioExistente) {
                    return res.status(404).json({ msg: "Email não cadastrado!" });
                }
            } else {
                return res.status(400).json({ msg: "Ação inválida" });
            }

            const verificationCode = generateVerificationCode();
            const token = generateToken({ email, action, verificationCode });

            let subject;
            if (action === "cadastro") {
                subject = "Código de Verificação";
            } else if (action === "recSenha") {
                subject = "Recuperação de senha";
            }

            await sendEmail(email, subject, verificationCode, email);
            
            return res.status(200).json({ msg: "Email enviado!", token }); // Retornar o token para fins de teste
        } catch (error) {
            console.error("Erro ao enviar email: ", error);
            return res.status(500).json({ msg: "Erro no envio do email!" });
        }
    },
    
    async validarCodigo(req, res) {
        const { code } = req.body;
        const token = req.headers["x-access-token"];

        if (!code) return res.status(400).json({ msg: "Campos obrigatórios não preenchidos" });

        try {
            const decoded = jwt.verify(token, process.env.JWT_SECRET);

            if (decoded.verificationCode !== code) {
                return res.status(401).json({ msg: "Código de verificação inválido" });
            }

            return res.status(200).json({ msg: "Token válido", email: decoded.email, acao: decoded.action });
        } catch (error) {
            console.error("Erro ao validar token: ", error);
            return res.status(401).json({ msg: "Token inválido ou expirado", error });
        }
    },

    async cadastrarUsuario(req, res) {
        const { nome, senha, repSenha, cursoId, telefone, dataNasc } = req.body;
        const token = req.headers["x-access-token"];
    
        if (!nome || !senha || !repSenha || !cursoId || !telefone || !dataNasc) {
            return res.status(400).json({ msg: "Campos obrigatórios inválidos" });
        }
    
        if (senha !== repSenha) return res.status(422).json({ msg: "Senhas diferentes!" });
    
        try {
            const decoded = jwt.verify(token, process.env.JWT_SECRET);
            if(decoded.email === undefined)
                return res.status(401).json({msg: "Usuário sem permissão de acesso"});  
    
            const usuarioExistente = await Usuario.findOne({ where: { email: decoded.email } });
    
            if (usuarioExistente) {
                return res.status(409).json({ msg: "Usuário já existente!" });
            }
    
            // Gerar hash da senha usando bcrypt
            const saltRounds = 10;
            const senhaHashed = await bcrypt.hash(senha, saltRounds);

            const novoUsuario = await Usuario.create({
                nome,
                email: decoded.email,
                senha: senhaHashed, // Armazenar a senha criptografada
                cursoId,
                telefone,
                data_nasc: dataNasc,
                master: false,
                tipo: "ESTUDANTE"
            });
    
            return res.status(201).json({ msg: "Usuário cadastrado com sucesso!", novoUsuario });
        } catch (error) {
            console.error(error);
            return res.status(500).json({ msg: "Erro de servidor", error });
        }
    },

    async novaSenha(req, res){
        const { senha, repSenha } = req.body;
        const token = req.headers["x-access-token"];

        if (!token)
            return res.status(401).json({ msg: "Usuário sem permissão de acesso" });

        if (!senha || !repSenha) return res.status(400).json({ msg: "Campos obrigatórios não preenchidos" });

        if (senha !== repSenha) return res.status(422).json({ msg: "Senhas diferentes!" });

        try {
            const decoded = jwt.verify(token, process.env.JWT_SECRET);
            const email = decoded.email;
            if (email === undefined)
                return res.status(401).json({ msg: "Usuário sem permissão de acesso" });  

            const usuario = await Usuario.findOne({ where: { email: email } });

            if (!usuario) return res.status(404).json({ msg: "Email não cadastrado" });

            const saltRounds = 10;
            const senhaHashed = await bcrypt.hash(senha, saltRounds);

            await usuario.update({
                senha: senhaHashed
            });

            return res.status(200).json({ msg: "Senha atualizada!" });
        } catch (error) {
            console.error(error);
            return res.status(500).json({ msg: "Erro de servidor" });
        }
    }
};
