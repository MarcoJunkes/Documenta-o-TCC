const PlanoAssinatura = require("../models/PlanoAssinatura");
const MembroAtletica = require("../models/MembroAtletica");
const Atletica = require("../models/Atletica");
const Assinatura = require("../models/Assinatura");

const AuthService = require("../services/authService");
const jwt = require("jsonwebtoken");

module.exports = {
    async buscarPorAtletica(req, res){
        const { id } = req.params;
        if(!id) return res.status(400).json({msg: "Id não fornecido!"});

        try{
            const atletica = await Atletica.findOne({where: {id: id}});
            if(!atletica) return res.status(400).json({msg: "Falha ao buscar Atlética!"});

            const plano = await PlanoAssinatura.findAll({
                where: {
                    atleticaId: id
                }
            });
            if(!plano) return res.status(400).json({msg: "Falha ao buscar plano!"});
            return res.status(200).json(plano);
        }catch(error){
            console.error(error);
            return res.status(500).json({msg: "Erro no servidor!"});
        }
    },

		async addPlano(req, res) {
			const { nome, descricao, valor, duracao, desconto } = req.body;
			const token = req.headers["x-access-token"];
		
			if (!nome || !descricao || !valor || !duracao) {
				return res.status(400).json({ msg: "Campos obrigatórios não preenchidos!" });
			}
		
			try {
				await AuthService.verificaPermissao(token, ["ADMIN"]);
		
				const decoded = jwt.verify(token, process.env.JWT_SECRET);
				const admin = await MembroAtletica.findOne({ where: { usuarioId: decoded.id } });
				const atletica = await Atletica.findOne({ where: { id: admin.atleticaId } });
		
				if (!admin || !atletica) return res.status(404).json({ msg: "Admin ou Atlética não encontrado!" });
		
				const planoExistente = await PlanoAssinatura.findOne({ where: { nome } });
				if (planoExistente) return res.status(409).json({ msg: "Plano já cadastrado!" });
		
				await PlanoAssinatura.create({
					atleticaId: atletica.id,
					nome,
					descricao,
					valor,
					duracao,
					desconto: desconto || 0.0
				});
		
				return res.status(201).json({ msg: "Plano cadastrado!" });
			} catch (error) {
				console.error(error);
				return res.status(500).json({ msg: "Erro no servidor!" });
			}
		},		

    async exibirPlanos(req, res) {
			try {
				const planos = await PlanoAssinatura.findAll();
		
				const planosComAtletica = await Promise.all(
					planos.map(async (plano) => {
						const atletica = await Atletica.findOne({ where: { id: plano.atleticaId } });
						return {
							...plano.toJSON(),
							atleticaNome: atletica ? atletica.nome : null,
						};
					})
				);
		
				return res.status(200).json({ planos: planosComAtletica });
			} catch (error) {
				console.error(error);
				return res.status(500).json({ msg: "Erro no servidor!" });
			}
		},		

    async selecionarPlanos(req, res) {
        const { id } = req.params;

        if (!id) return res.status(400).json({ msg: "Id não fornecido!" });

        try {
            const plano = await PlanoAssinatura.findOne({ where: { id: id } });
            if (!plano) return res.status(404).json({ msg: "Plano não encontrado!" });

          
            return res.status(200).json({ ...plano.toJSON() });
        } catch (error) {
            console.error(error);
            return res.status(500).json({ msg: "Erro no servidor!" });
        }
    },

		async editarPlano(req, res) {
			const { id } = req.params;
			const { nome, descricao, valor, duracao, desconto, beneficios } = req.body;
			const token = req.headers["x-access-token"];
		
			if (!id) return res.status(400).json({ msg: "Id não fornecido!" });
		
			try {
				await AuthService.verificaPermissao(token, ["ADMIN"]);
		
				const plano = await PlanoAssinatura.findByPk(id);
				if (!plano) return res.status(404).json({ msg: "Plano não encontrado!" });
		
				const dadosAtualizados = {};
				if (nome) dadosAtualizados.nome = nome;
				if (descricao) dadosAtualizados.descricao = descricao;
				if (valor) dadosAtualizados.valor = valor;
				if (duracao) dadosAtualizados.duracao = duracao;
				if (desconto !== undefined) dadosAtualizados.desconto = desconto;
				if (beneficios) dadosAtualizados.beneficios = Array.isArray(beneficios) ? beneficios : JSON.parse(beneficios);
		
				await plano.update(dadosAtualizados);
		
				return res.status(200).json({ msg: "Plano atualizado!" });
			} catch (error) {
				console.error(error);
				return res.status(500).json({ msg: "Erro no servidor!" });
			}
		},		

    async removerPlano(req, res) {
        const { id } = req.params;
        const token = req.headers["x-access-token"];

        if (!id) return res.status(400).json({ msg: "Id não fornecido!" });

        try {
            await AuthService.verificaPermissao(token, ["ADMIN"]);
        } catch (error) {
            console.error(error.message);
            return res.status(401).json({ msg: error.message });
        }

        try {
            const plano = await PlanoAssinatura.findByPk(id);
            if (!plano) return res.status(404).json({ msg: "Plano não encontrado!" });

            const assinatura = await Assinatura.findOne({
                where: {
                    planoId: plano.id,
                    statusAssinatura: "PAGA"
                }
            });

            if(assinatura)
                return res.status(404).json({msg: "Não é possível deletar o plano enquanto há assinantes ativos!"});

						await Assinatura.destroy({
							where: {
									planoId: plano.id
							}
					});

            await plano.destroy();

            return res.status(200).json({ msg: "Plano removido!" });
        } catch (error) {
            console.error(error);
            return res.status(500).json({ msg: "Erro no servidor!" });
        }
    },

    async visualizarAssinantes(req, res){
        const { id } = req.params;
        const token = req.headers["x-access-token"];

        if(!id)
            return res.status(400).json({msg: "Id não fornecido!"});

        try {
            await AuthService.verificaPermissao(token, ["ADMIN"]);
        } catch (error) {
            console.error(error.message);
            return res.status(401).json({ msg: error.message });
        }

        try{
            const assinantes  = await Assinatura.findAll({where: {planoId: id}});
            if(!assinantes)
                return res.status(404).json({msg: "Falha ao buscar Assinantes"});

            return res.status(200).json({assinantes});
        }catch(error){
            console.error(error);
        }
    }
}
