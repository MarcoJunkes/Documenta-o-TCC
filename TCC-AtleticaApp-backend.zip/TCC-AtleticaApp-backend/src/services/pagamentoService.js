const Stripe = require("stripe");
const stripe = Stripe(process.env.STRIPE_SECRET_KEY);

async function realizarPagamento({ descricao, valor, forma, metadata }) {
    try {
        // Cria uma sessão de pagamento no Stripe
        const session = await stripe.checkout.sessions.create({
            payment_method_types: [forma],
            line_items: [
                {
                    price_data: {
                        currency: 'brl',
                        product_data: { name: descricao },
                        unit_amount: Math.round(valor * 100), // Valor em centavos
                    },
                    quantity: 1,
                },
            ],
            mode: 'payment',
            success_url: `${process.env.FRONTEND_URL}/success?session_id={CHECKOUT_SESSION_ID}`,
            cancel_url: `${process.env.FRONTEND_URL}/cancel`,
            metadata: metadata // Informações extras que podem variar (como assinaturaId, produtoId, etc.)
        });

        return { url: session.url };
    } catch (error) {
        console.error("Erro ao realizar pagamento:", error);
        return { error: true };
    }
}

module.exports = realizarPagamento;
