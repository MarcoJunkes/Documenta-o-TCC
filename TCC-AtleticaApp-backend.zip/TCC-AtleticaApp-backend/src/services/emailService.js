const nodemailer = require("nodemailer");
const fs = require("fs");
const path = require("path");

const transporter = nodemailer.createTransport({
    host: 'smtp.gmail.com',
    port: 587,
    secure: false,
    auth: {
        user: process.env.EMAIL_USER,
        pass: process.env.EMAIL_PASS
    },
    tls: {
        rejectUnauthorized: false
    },
    greetingTimeout: 20000,
    connectionTimeout: 20000, 
		socketTimeout: 20000
});

async function sendEmail(to, subject, code){
    try{
        const templatePath = path.join(__dirname, '..', 'template', 'emailTemplate.html');
        let htmlContent = fs.readFileSync(templatePath, 'utf8');

        htmlContent = htmlContent.replace('{{code}}', code);

        const info = await transporter.sendMail({
            from: process.env.EMAIL_USER,
            to,
            subject,
            html: htmlContent,
        });

        console.log("Email enviado: %s", info.messageId);
    }catch(error){
        console.error("Erro ao enviar email: ", error);
    }
}

module.exports = { sendEmail };