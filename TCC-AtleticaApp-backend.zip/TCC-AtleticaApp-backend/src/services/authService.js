const jwt = require("jsonwebtoken");
const Usuario = require("../models/Usuario");

class AuthService {
    async verificaPermissao(token, tiposPermitidos){
        if(!token){
            throw new Error("Token não fornecido!");
        }

        let decoded;
        try{
            decoded = jwt.verify(token, process.env.JWT_SECRET);
        } catch(error){
            throw new Error("Token inválido");
        }

        const usuario = await Usuario.findOne({where: {id: decoded.id}});
        if(!usuario){
            throw new Error("Usuário não encontrado");
        }

        if(!tiposPermitidos.includes(usuario.tipo)){
            throw new Error("Usuário sem permissão de acesso");
        }

        return usuario;
    }
}

module.exports = new AuthService();