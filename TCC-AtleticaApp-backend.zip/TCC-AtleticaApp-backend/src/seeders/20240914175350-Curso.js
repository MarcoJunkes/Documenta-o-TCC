"use strict";

/** @type {import('sequelize-cli').Migration} */
module.exports = {
  async up(queryInterface, Sequelize) {
    return queryInterface.bulkInsert("Curso", [
      {
        nome: "Administração",
        departamento: "Setor de Ciências Sociais Aplicadas - Curitiba",
      },
      {
        nome: "Agronomia",
        departamento: "Setor de Ciências Agrárias - Curitiba",
      },
      {
        nome: "Agronomia",
        departamento: "Setor de Palotina",
      },
      {
        nome: "Arquitetura e Urbanismo",
        departamento: "Setor de Tecnologia - Curitiba",
      },
      {
        nome: "Artes (Licenciatura)",
        departamento: "Setor Litoral - Matinhos",
      },
      {
        nome: "Artes Visuais (Bacharelado)",
        departamento: "Setor de Artes, Comunicação e Design - Curitiba",
      },
      {
        nome: "Artes Visuais (Licenciatura)",
        departamento: "Setor de Artes, Comunicação e Design - Curitiba",
      },
      {
        nome: "Biomedicina",
        departamento: "Setor de Ciências Biológicas - Curitiba",
      },
      {
        nome: "Ciência da Computação (Bacharelado)",
        departamento: "Setor de Ciências Exatas - Curitiba",
      },
      {
        nome: "Ciências - Licenciatura",
        departamento: "Setor Litoral - Matinhos",
      },
      {
        nome: "Ciências Biológicas",
        departamento: "Setor de Ciências Biológicas - Curitiba",
      },
      {
        nome: "Ciências Biológicas",
        departamento: "Setor de Palotina",
      },
      {
        nome: "Ciências Contábeis",
        departamento: "Setor de Ciências Sociais Aplicadas - Curitiba",
      },
      {
        nome: "Ciências Econômicas",
        departamento: "Setor de Ciências Sociais Aplicadas - Curitiba",
      },
      {
        nome: "Ciências Exatas (Licenciatura)",
        departamento: "Setor de Palotina",
      },
      {
        nome: "Ciências Exatas (Licenciatura)",
        departamento:
          "Setor de Ciências da Terra - Curitiba e Pontal do Paraná",
      },
      {
        nome: "Ciências Exatas (Licenciatura)",
        departamento: "Campus Jandaia do Sul",
      },
      {
        nome: "Ciências Sociais",
        departamento: "Setor de Ciências Humanas - Curitiba",
      },
      {
        nome: "Computação (Licenciatura)",
        departamento: "Campus Jandaia do Sul",
      },
      {
        nome: "Computação (Licenciatura)",
        departamento: "Setor de Palotina",
      },
      {
        nome: "Comunicação Social - Jornalismo",
        departamento: "Setor de Artes, Comunicação e Design - Curitiba",
      },
      {
        nome: "Comunicação Social - Publicidade e Propaganda",
        departamento: "Setor de Artes, Comunicação e Design - Curitiba",
      },
      {
        nome: "Comunicação Social - Relações Públicas",
        departamento: "Setor de Artes, Comunicação e Design - Curitiba",
      },
      {
        nome: "Design - Design de Produto",
        departamento: "Setor de Artes, Comunicação e Design - Curitiba",
      },
      {
        nome: "Design - Design Gráfico",
        departamento: "Setor de Artes, Comunicação e Design - Curitiba",
      },
      {
        nome: "Direito",
        departamento: "Setor de Ciências Jurídicas - Curitiba",
      },
      {
        nome: "Educação Física (Licenciatura)",
        departamento: "Setor Litoral - Matinhos",
      },
      {
        nome: "Educação Física (Bacharelado)",
        departamento: "Setor de Ciências Biológicas - Curitiba",
      },
      {
        nome: "Educação Física (Licenciatura)",
        departamento: "Setor de Ciências Biológicas - Curitiba",
      },
      {
        nome: "Engenharia Agrícola",
        departamento: "Campus Jandaia do Sul",
      },
      {
        nome: "Engenharia Ambiental",
        departamento: "Setor de Tecnologia - Curitiba",
      },
      {
        nome: " Engenharia Ambiental e Sanitária ",
        departamento:
          "Setor de Ciências da Terra - Curitiba e Pontal do Paraná",
      },
      {
        nome: "Engenharia Cartográfica e de Agrimensura",
        departamento:
          "Setor de Ciências da Terra - Curitiba e Pontal do Paraná",
      },
      {
        nome: "Engenharia Civil",
        departamento: "Setor de Tecnologia - Curitiba",
      },
      {
        nome: "Engenharia Civil",
        departamento:
          "Setor de Ciências da Terra - Curitiba e Pontal do Paraná",
      },
      {
        nome: "Engenharia de Alimentos",
        departamento: "Campus Jandaia do Sul",
      },
      {
        nome: "Engenharia de Aquicultura",
        departamento:
          "Setor de Ciências da Terra - Curitiba e Pontal do Paraná",
      },
      {
        nome: "Engenharia de Aquicultura",
        departamento: "Setor de Palotina",
      },
      {
        nome: "Engenharia de Bioprocessos e Biotecnologia",
        departamento: "Setor de Tecnologia - Curitiba",
      },
      {
        nome: "Engenharia de Energias Renováveis",
        departamento: "Setor de Palotina",
      },
      {
        nome: "Engenharia de Produção",
        departamento: "Setor de Tecnologia - Curitiba",
      },
      {
        nome: "Engenharia de Produção",
        departamento: "Campus Jandaia do Sul",
      },

      {
        nome: "Engenharia Elétrica (Ênfase em Sistemas Eletrônicos Embarcados)",
        departamento: "Setor de Tecnologia - Curitiba",
      },
      {
        nome: "Engenharia Florestal",
        departamento: "Setor de Ciências Agrárias - Curitiba",
      },
      {
        nome: "Engenharia Industrial Madeireira",
        departamento: "Setor de Ciências Agrárias - Curitiba",
      },
      {
        nome: "Engenharia Mecânica",
        departamento: "Setor de Tecnologia - Curitiba",
      },
      {
        nome: "Engenharia Química",
        departamento: "Setor de Tecnologia - Curitiba",
      },
      {
        nome: "Estatística",
        departamento: "Setor de Ciências Exatas - Curitiba",
      },
      {
        nome: "Expressão Gráfica",
        departamento: "Setor de Ciências Exatas - Curitiba",
      },
      {
        nome: "Farmácia",
        departamento: "Setor de Ciências da Saúde - Curitiba",
      },
      {
        nome: "Filosofia (Bacharelado com Licenciatura Plena)",
        departamento: "Setor de Ciências Humanas - Curitiba",
      },

      {
        nome: "Física (Bacharelado)",
        departamento: "Setor de Ciências Exatas - Curitiba",
      },
      {
        nome: "Física (Licenciatura)",
        departamento: "Setor de Ciências Exatas - Curitiba",
      },
      {
        nome: "Fisioterapia",
        departamento: "Setor de Ciências Biológicas - Curitiba",
      },
      {
        nome: "Geografia",
        departamento:
          "Setor de Ciências da Terra - Curitiba e Pontal do Paraná",
      },
      {
        nome: "Geologia",
        departamento:
          "Setor de Ciências da Terra - Curitiba e Pontal do Paraná",
      },
      {
        nome: "Gestão Ambiental (Bacharelado)",
        departamento: "Setor Litoral - Matinhos",
      },
      {
        nome: "Gestão da Informação",
        departamento: "Setor de Ciências Sociais Aplicadas- Curitiba",
      },
      {
        nome: "Gestão e Empreendedorismo (Bacharelado)",
        departamento: "Setor Litoral - Matinhos",
      },
      {
        nome: "Gestão Pública (Bacharelado)",
        departamento: "Setor Litoral - Matinhos",
      },
      {
        nome: "Informática Biomédica (Bacharelado)",
        departamento: "Setor de Ciências Exatas - Curitiba",
      },
      {
        nome: "Letras - Espanhol ou Português com Espanhol",
        departamento: "Setor de Ciências Humanas - Curitiba",
      },
      {
        nome: "Letras - Francês",
        departamento: "Setor de Ciências Humanas - Curitiba",
      },
      {
        nome: "Letras - Inglês",
        departamento: "Setor de Ciências Humanas - Curitiba",
      },
      {
        nome: "Letras - Inglês ou Português com Inglês",
        departamento: "Setor de Ciências Humanas - Curitiba",
      },
      {
        nome: "Letras - Italiano ou Português com Italiano",
        departamento: "Setor de Ciências Humanas - Curitiba",
      },
      {
        nome: "Letras - Japonês",
        departamento: "Setor de Ciências Humanas - Curitiba",
      },
      {
        nome: "Letras - Polonês",
        departamento: "Setor de Ciências Humanas - Curitiba",
      },
      {
        nome: "Letras - Port. ou Alem. ou Greg. ou Lat. ou Port.+Alem. ou +Greg. ou +Lat.",
        departamento: "Setor de Ciências Humanas - Curitiba",
      },
      {
        nome: "Letras - Português",
        departamento: "Setor de Ciências Humanas - Curitiba",
      },
      {
        nome: "Linguagem e Comunicação (Licenciatura)",
        departamento: "Setor Litoral - Matinhos",
      },
      {
        nome: "Matemática (Bacharelado e Licenciatura)",
        departamento: "Setor de Ciências Exatas - Curitiba",
      },
      {
        nome: "Matemática (Licenciatura)",
        departamento: "Setor de Ciências Exatas - Curitiba",
      },
      {
        nome: "Matemática Industrial",
        departamento: "Setor de Ciências Exatas - Curitiba",
      },
      {
        nome: "Medicina",
        departamento: "Setor de Ciências da Saúde - Curitiba",
      },
      {
        nome: "Medicina",
        departamento: "Campus Toledo",
      },
      {
        nome: "Medicina Veterinária",
        departamento: "Setor de Ciências Agrárias - Curitiba",
      },
      {
        nome: "Medicina Veterinária",
        departamento: "Setor de Palotina",
      },

      {
        nome: "Música (Bacharelado) - Prod. Musical/Criação Musical)",
        departamento: "Setor de Artes, Comunicação e Design - Curitiba",
      },
      {
        nome: "Música (Licenciatura) - Educação Musical",
        departamento: "Setor de Artes, Comunicação e Design - Curitiba",
      },
      {
        nome: "Nutrição",
        departamento: "Setor de Ciências da Saúde - Curitiba",
      },
      {
        nome: "Oceanografia",
        departamento:
          "Setor de Ciências da Terra - Curitiba e Pontal do Paraná",
      },
      {
        nome: "Odontologia",
        departamento: "Setor de Ciências da Saúde - Curitiba",
      },
      {
        nome: "Pedagogia",
        departamento: "Setor de Educação - Curitiba",
      },
      {
        nome: "Psicologia",
        departamento: "Setor de Ciências Humanas - Curitiba",
      },
      {
        nome: "Química (Licenciatura e Bacharelado)",
        departamento: "Setor de Ciências Exatas - Curitiba",
      },
      {
        nome: "Química (Licenciatura)",
        departamento: "Setor de Ciências Exatas - Curitiba",
      },
      {
        nome: "Saúde Coletiva (Bacharelado)",
        departamento: "Setor Litoral - Matinhos",
      },
      {
        nome: "Serviço Social (Bacharelado)",
        departamento: "Setor Litoral - Matinhos",
      },
      {
        nome: "Tecnologia em Agroecologia",
        departamento: "Setor Litoral - Matinhos",
      },
      {
        nome: "Tecnologia em Análise e Desenvolvimento de Sistemas",
        departamento: "Setor de Educação Profissional e Tecnológica - Curitiba",
      },
      {
        nome: "Tecnologia em Biotecnologia",
        departamento: "Setor de Palotina",
      },
      {
        nome: "Tecnologia em Comunicação Institucional",
        departamento: "Setor de Educação Profissional e Tecnológica - Curitiba",
      },
      {
        nome: "Tecnologia em Gestão da Qualidade",
        departamento: "Setor de Educação Profissional e Tecnológica - Curitiba",
      },
      {
        nome: "Tecnologia em Gestão de Turismo",
        departamento: "Setor Litoral - Matinhos",
      },
      {
        nome: "Tecnologia em Gestão Imobiliária",
        departamento: "Setor Litoral - Matinhos",
      },
      {
        nome: "Tecnologia em Gestão Pública",
        departamento: "Setor de Educação Profissional e Tecnológica - Curitiba",
      },
      {
        nome: "Tecnologia em Luteria",
        departamento: "Setor de Educação Profissional e Tecnológica - Curitiba",
      },
      {
        nome: "Tecnologia em Negócios Imobiliários",
        departamento: "Setor de Educação Profissional e Tecnológica - Curitiba",
      },
      {
        nome: "Tecnologia em Produção Cênica",
        departamento: "Setor de Educação Profissional e Tecnológica - Curitiba",
      },
      {
        nome: "Tecnologia em Secretariado",
        departamento: "Setor de Educação Profissional e Tecnológica - Curitiba",
      },
      {
        nome: "Terapia Ocupacional",
        departamento: "Setor de Ciências da Saúde - Curitiba",
      },
      {
        nome: "Turismo",
        departamento: "Setor de Ciências Humanas - Curitiba",
      },
      {
        nome: "Zootecnia",
        departamento: "Setor de Ciências Agrárias - Curitiba",
      },
    ]);
  },

  async down(queryInterface, Sequelize) {
    return queryInterface.bulkDelete("Curso", null, {});
  },
};
