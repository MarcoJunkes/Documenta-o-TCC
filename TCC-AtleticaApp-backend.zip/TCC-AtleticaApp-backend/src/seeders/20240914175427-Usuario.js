'use strict';

const bcrypt = require("bcrypt");

/** @type {import('sequelize-cli').Migration} */
module.exports = {
  async up (queryInterface, Sequelize) {
    const saltRounds = 10;

    const senhaCriptografada = await bcrypt.hash("master", saltRounds);

    return queryInterface.bulkInsert(
      "Usuario",
      [
        {
          cursoId: 7,
          nome: "master",
          email: "master@master.com",
          senha: senhaCriptografada,
          telefone: "master",
          data_nasc: new Date(),
          master: true,
          tipo: "master"
        },
      ]
    );
  },

  async down (queryInterface, Sequelize) {
    return queryInterface.bulkDelete("Usuario", null, {});
  },
};
