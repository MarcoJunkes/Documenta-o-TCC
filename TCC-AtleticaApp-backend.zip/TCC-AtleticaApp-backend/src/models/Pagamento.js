const Sequelize = require("sequelize");

class Pagamento extends Sequelize.Model{
    static init(sequelize){
        super.init(
            {
                descricao: Sequelize.STRING,
                valor: Sequelize.FLOAT,
                data: Sequelize.DATE,
                forma: Sequelize.STRING
            },
            {
                tableName: "Pagamento",
                sequelize
            }
        );
    }

    static associate(models){
        this.belongsToMany(models.Assinatura, {
            through: models.PagamentoAssinatura,
            foreignKey: "pagamentoId",
            otherKey: "assinaturaId",
          });      
          
        this.belongsToMany(models.Pedido, {
            through: models.PagamentoPedido,
            foreignKey: "pagamentoId",
            otherKey: "idPedido"
        });
    }
}

module.exports = Pagamento;