const Sequelize = require("sequelize");

class UsuarioEvento extends Sequelize.Model {
    static init(sequelize) {
        super.init(
            {
                eventoId: {
                    type: Sequelize.INTEGER,
                    allowNull: false,
                    references: {
                        model: 'Eventos',
                        key: 'id'
                    }
                },
                usuarioId: {
                    type: Sequelize.INTEGER,
                    allowNull: false,
                    references: {
                        model: 'Usuarios',
                        key: 'id'
                    }
                }
            },
            {
                tableName: "UsuarioEvento",
                sequelize,
            }
        );
    }

    static associate(models) {
        this.belongsTo(models.Evento, { foreignKey: "eventoId" });
        this.belongsTo(models.Usuario, { foreignKey: "usuarioId" });
    }
}

module.exports = UsuarioEvento;