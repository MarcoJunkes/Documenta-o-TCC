const Sequelize = require("sequelize");

class PagamentoPedido extends Sequelize.Model {
    static init(sequelize){
        super.init(
            {},
            {
                tableName: "PagamentoPedido",
                sequelize,
            }
        );
    }

    static associate(models){

    }
}

module.exports = PagamentoPedido;