const Sequelize = require("sequelize");

class PlanoAssinatura extends Sequelize.Model{
    static init(sequelize){
        super.init(
            {
                atleticaId: Sequelize.INTEGER,
                nome: Sequelize.STRING,
                descricao: Sequelize.STRING,
                valor: Sequelize.FLOAT,
                duracao: Sequelize.INTEGER,
								desconto: {
									type: Sequelize.FLOAT,	
									defaultValue: 0.0
								},
								beneficios: {
									type: Sequelize.JSON,
									defaultValue: []
								}
            },
            {
                tableName: "PlanoAssinatura",
                sequelize,
            }
        );
    }

    static associate(models){
			this.belongsTo(models.Atletica, {foreignKey: "atleticaId"});
			this.hasMany(models.Assinatura, {foreignKey: "planoId"});
	}
}

module.exports = PlanoAssinatura;