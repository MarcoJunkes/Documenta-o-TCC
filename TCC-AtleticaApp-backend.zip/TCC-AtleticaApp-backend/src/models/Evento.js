const Sequelize = require("sequelize");

class Evento extends Sequelize.Model {
    static init(sequelize) {
        super.init(
            {
                data: {
                    type: Sequelize.STRING,
                    allowNull: false,
                },
                hora: {
                    type: Sequelize.STRING,
                    allowNull: false,
                },
                endereco: {
                    type: Sequelize.STRING,
                    allowNull: false,
                },
                titulo: {
                    type: Sequelize.STRING,
                    allowNull: false,
                },
                descricao: {
                    type: Sequelize.STRING,
                    allowNull: false,
                },
                linkPlataformaIngressos: {
                    type: Sequelize.STRING,
                    allowNull: true,
                },
                qtdeVagas: {
                    type: Sequelize.INTEGER,
                    allowNull: true,
                },
                ingresso: {
                    type: Sequelize.INTEGER,
                    allowNull: true,
                },
                statusEvento: {
                    type: Sequelize.ENUM('CONCLUIDO', 'CANCELADO', 'EM_ANDAMENTO'),
                    allowNull: false,
                },
                modalidade: {
                    type: Sequelize.ENUM('FESTA', 'JOGO'),
                    allowNull: false,
                },
                atleticaId: {
                    type: Sequelize.INTEGER,
                    allowNull: false,
                },
                atleticaName: {
                    type: Sequelize.STRING,
                    allowNull: false,
                },
            },
            {
                sequelize,
                tableName: "Evento",
            }
        );
    }

    static associate(models) {
        this.belongsTo(models.Atletica, { foreignKey: 'atleticaId', onDelete: 'SET NULL' });
        this.belongsToMany(models.Usuario, {
            through: models.UsuarioEvento,
            foreignKey: "eventoId",
            otherKey: "usuarioId"
        });
    }
}

module.exports = Evento;