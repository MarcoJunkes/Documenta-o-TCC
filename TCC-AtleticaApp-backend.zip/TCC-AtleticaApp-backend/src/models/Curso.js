const Sequelize = require("sequelize");

class Curso extends Sequelize.Model {
    static init(sequelize) {
        super.init(
            {
                nome: Sequelize.STRING,
                departamento: Sequelize.STRING,
            },
            {
                tableName: "Curso",
                sequelize,
            }
        );
    }

    static associate(models) {
        this.belongsToMany(models.Atletica, {
            through: models.AtleticaCurso, // Referência ao modelo da tabela de junção
            foreignKey: "cursoId",
            otherKey: "atleticaId",
        });
        this.hasMany(models.Usuario, {foreignKey: "cursoId"});
    }
}

module.exports = Curso;
