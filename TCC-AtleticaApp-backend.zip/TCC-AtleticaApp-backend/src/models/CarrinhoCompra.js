const Sequelize = require("sequelize");

class CarrinhoCompra extends Sequelize.Model{
    static init(sequelize){
        super.init(
            {
                data: Sequelize.DATE,
                status: Sequelize.STRING,
                valorTotal: Sequelize.FLOAT
            },
            {
                tableName: "CarrinhoCompra",
                sequelize
            }
        );
    }

    static associate(models){
        this.belongsToMany(models.Produto, {
            through: models.ProdutoCarrinhoCompra,
            foreignKey: "carrinhoCompraId",
            otherKey: "produtoId",
            as: "produtos"
        });

        this.belongsTo(models.Usuario, {foreignKey: "usuarioId"});
        this.hasMany(models.Pedido, {foreignKey: "idCarrinho"});
    }
}

module.exports = CarrinhoCompra;