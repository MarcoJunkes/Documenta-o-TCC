const Sequelize = require("sequelize");

class MembroAtletica extends Sequelize.Model {
    static init(sequelize) {
        super.init(
            {
                administrador: {
                    type: Sequelize.BOOLEAN,
                    defaultValue:false,
                    allowNull: false,
                },
            },
            {
                sequelize,
                tableName: "MembroAtletica", 
            }
        );
    }
    
    static associate(models) {
        this.belongsTo(models.Usuario, { foreignKey: 'usuarioId', onDelete: 'SET NULL'});
        //onDelete: set null -> se o campo for deletado, a fk será null
        this.belongsTo(models.Atletica, { foreignKey: 'atleticaId', onDelete: 'SET NULL' });
    }
}

module.exports = MembroAtletica;