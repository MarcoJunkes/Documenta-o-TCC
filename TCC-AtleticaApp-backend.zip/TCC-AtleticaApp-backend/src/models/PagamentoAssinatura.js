const Sequelize = require("sequelize");

class PagamentoAssinatura extends Sequelize.Model {
    static init(sequelize){
        super.init(
            {},
            {
                tableName: "PagamentoAssinatura",
                sequelize,
            }
        );
    }

    static associate(models){
        
    }
}

module.exports = PagamentoAssinatura;