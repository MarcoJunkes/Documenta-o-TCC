const Sequelize = require("sequelize");

class AtleticaCurso extends Sequelize.Model {
    static init(sequelize) {
        super.init(
            {},
            {
                tableName: "AtleticaCurso",
                sequelize,
            }
        );
    }
}

module.exports = AtleticaCurso;
