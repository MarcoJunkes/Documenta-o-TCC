const Sequelize = require("sequelize");

class Produto extends Sequelize.Model{
    static init(sequelize){
        super.init(
            {
                atleticaId: Sequelize.INTEGER,
                nome: Sequelize.STRING,
                imagem: Sequelize.STRING,
                valor: Sequelize.FLOAT,
                quantidade: Sequelize.INTEGER
            },
            {
                tableName: "Produto",
                sequelize
            }
        );
    }

    static associate(models){
        this.belongsTo(models.Atletica, {foreignKey: "atleticaId"});

        this.belongsToMany(models.CarrinhoCompra, {
            through: models.ProdutoCarrinhoCompra,
            foreignKey: "produtoId",
            otherKey: "carrinhoCompraId",
            as: "carrinhos"
        });
    }
}

module.exports = Produto;