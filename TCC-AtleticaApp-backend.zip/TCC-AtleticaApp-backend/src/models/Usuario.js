const Sequelize = require("sequelize");

class Usuario extends Sequelize.Model{
    static init(sequelize){
        super.init(
            {
                cursoId: Sequelize.INTEGER,
                nome: Sequelize.STRING,
                email: Sequelize.STRING,
                senha: Sequelize.STRING,
                telefone: Sequelize.STRING,
                data_nasc: Sequelize.DATE,
                master: Sequelize.BOOLEAN,
                tipo: Sequelize.STRING,
            },
            {
                tableName: "Usuario",
                sequelize,
            }
        );
    }

    static associate(models){
        this.belongsTo(models.Curso, {foreignKey: "cursoId"});
        this.hasMany(models.Assinatura, {foreignKey: "usuarioId"});
        this.hasMany(models.CarrinhoCompra, {foreignKey: "usuarioId"});
        this.hasMany(models.Pedido, {foreignKey: "usuarioId"});
        this.belongsToMany(models.Evento, {
            through: models.UsuarioEvento,
            foreignKey: "usuarioId",
            otherKey: "eventoId"
        });
    }
}

module.exports = Usuario;