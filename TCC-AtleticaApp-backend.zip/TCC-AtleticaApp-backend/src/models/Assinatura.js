const Sequelize = require("sequelize");

class Assinatura extends Sequelize.Model{
    static init(sequelize){
        super.init(
            {
                usuarioId: Sequelize.INTEGER,
                planoId: Sequelize.INTEGER,
                dataInicio: Sequelize.DATE,
                dataFim: Sequelize.DATE,
                statusAssinatura: Sequelize.STRING
            },
            {
                tableName: "Assinatura",
                sequelize
            }
        );
    }

    static associate(models){
        this.belongsToMany(models.Pagamento, {
            through: models.PagamentoAssinatura,
            foreignKey: "assinaturaId",
            otherKey: "pagamentoId",
          });                

        this.belongsTo(models.Usuario, {foreignKey: "usuarioId"});
        this.belongsTo(models.PlanoAssinatura, {foreignKey: "planoId"})
    }
}

module.exports = Assinatura;