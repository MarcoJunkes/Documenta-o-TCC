const Sequelize = require("sequelize");

class ProdutoCarrinhoCompra extends Sequelize.Model {
    static init(sequelize) {
        super.init(
            {
                quantidade: Sequelize.INTEGER
            },
            {
                tableName: "ProdutoCarrinhoCompra",
                sequelize,
            }
        );
    }

    static associate(models) {
        this.belongsTo(models.Produto, {
            foreignKey: "produtoId",
            as: "produto"
        });

        this.belongsTo(models.CarrinhoCompra, {
            foreignKey: "carrinhoCompraId",
            as: "carrinho"
        });
    }
}

module.exports = ProdutoCarrinhoCompra;
