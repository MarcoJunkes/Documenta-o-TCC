const Sequelize = require("sequelize");

class Pedido extends Sequelize.Model{
    static init(sequelize){
        super.init(
            {
                idCarrinho: Sequelize.INTEGER,
                usuarioId: Sequelize.INTEGER,
                data: Sequelize.DATE,
                status: Sequelize.STRING,
                valorTotal: Sequelize.FLOAT
            },
            {
                tableName: "Pedido",
                sequelize
            }
        );
    }

    static associate(models){
        this.belongsTo(models.Usuario, {foreignKey: "usuarioId"});
        this.belongsTo(models.CarrinhoCompra, {foreignKey: "idCarrinho"});

        this.belongsToMany(models.Pagamento, {
            through: models.PagamentoPedido,
            foreignKey: "idPedido",
            otherKey: "pagamentoId"
        });
    }
}

module.exports = Pedido;