const Sequelize = require("sequelize");

class Atletica extends Sequelize.Model {
    static init(sequelize) {
        super.init(
            {
                nome: Sequelize.STRING,
                descricao: Sequelize.STRING,
                imagem: Sequelize.STRING,
                atividades:  Sequelize.ARRAY(Sequelize.STRING),
            },
            {
                tableName: "Atletica",
                sequelize,
            }
        );
    }

    static associate(models) {
        this.belongsToMany(models.Curso, {
            through: models.AtleticaCurso, // Referência ao modelo da tabela de junção
            foreignKey: "atleticaId",
            otherKey: "cursoId",
        });

        this.hasMany(models.MembroAtletica, { foreignKey: "atleticaId"});
        this.hasMany(models.PlanoAssinatura, { foreignKey: "atleticaId" });
        this.hasMany(models.Produto, { foreignKey: "atleticaId" });
    }
}

module.exports = Atletica;
