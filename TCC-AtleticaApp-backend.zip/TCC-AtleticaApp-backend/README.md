# COMANDOS PARA INSTALAR E EXECUTAR O PROJETO

1. **Clone o repositório**
    ```bash
    git clone https://github.com/MarcoJunkes/TCC-AtleticaApp-backend.git
    cd TCC-AtleticaApp-backend

2. **Instale o pacote npm**
    ```bash
    npm install

3. **Configure o .env**
    ```bash
    cp .env.example .env

4. **Execute as migrations**
    ```bash
    npx sequelize db:migrate --migrations-path src/migrations

5. **Execute os seeders**
    ```bash
    npx sequelize db:seed:all --seeders-path src/seeders

6. **Rode o projeto**
    ```bash
    npm run dev

7. **Acessando a documentação da API**
    ```bash
    http://localhost:3001/api-docs/#/

8. **Executando o STRIPE para a realização de pagamento**
    ```bash
    stripe listen --forward-to localhost:3001/webhook
